// ============================================================
// 通用看板 HTML 生成器
// 读取 config.json + dashboard_data.json → 输出 HTML 看板
// 用法: node gen_dashboard.js
// ============================================================
const fs = require('fs');
const path = require('path');

// 读取配置（支持 // 注释，自动去除后再解析）
function loadJsonWithComments(filePath) {
  let text = fs.readFileSync(filePath, 'utf8');
  text = text.replace(/\/\*[\s\S]*?\*\//g, '');
  text = text.replace(/^\s*\/\/.*$/gm, '').replace(/\s+\/\/.*$/gm, '');
  return JSON.parse(text);
}

const config = loadJsonWithComments(path.join(__dirname, 'config.json'));
const data = JSON.parse(fs.readFileSync(path.join(__dirname, config.outputJson), 'utf8'));
const dataStr = JSON.stringify(data);

// 工作内容来自 Excel「工作内容」sheet（extract.js 解析后写入 JSON），角色标签仍取自 config.roles
const roles = config.roles;
const WORK_CONTENT = (data.workContent || []).map(p => ({
  name: p.name,
  role: roles[p.name] || '运营',
  items: p.items
}));

const monthLabel = config.monthLabel;
const weekLabels = (config.monthCumulative && config.monthCumulative.weekLabels) || [];

// 逐周拆分文案：周标签从 config.weekLabels 读取，缺省回退「第N周」（不再硬编码月份日期）
const monthProfitTextA = (data.calibreA.monthProfitWeeks || [])
  .map((v, i) => `${weekLabels[i] || '第' + (i + 1) + '周'} 利润 ${v.toFixed(2)}`)
  .join(' + ');
const monthProfitTextB = (data.calibreB.monthProfitWeeks || [])
  .map((v, i) => `${weekLabels[i] || '第' + (i + 1) + '周'} 利润 ${v.toFixed(2)}`)
  .join(' + ');

const crossMonthNote = config.crossMonth && config.crossMonth.enabled
  ? `<br>注：${config.crossMonth.note}`
  : '';

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>${config.reportTitle}</title>
<script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"></script>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif; background: #f5f5f5; color: #333; font-size: 14px; line-height: 1.5; }
  .container { max-width: 1600px; margin: 0 auto; padding: 20px; }
  .header { background: #fff; border: 1px solid #e0e0e0; padding: 16px 20px; margin-bottom: 16px; }
  .header h1 { font-size: 20px; font-weight: 600; margin-bottom: 4px; }
  .header .subtitle { font-size: 12px; color: #888; }
  .tabs { display: flex; border: 1px solid #e0e0e0; border-bottom: none; background: #fff; }
  .tab { padding: 12px 24px; cursor: pointer; border-right: 1px solid #e0e0e0; font-size: 14px; color: #666; transition: all 0.2s; }
  .tab:hover { background: #fafafa; }
  .tab.active { background: #1890ff; color: #fff; font-weight: 500; }
  .page { display: none; background: #fff; border: 1px solid #e0e0e0; padding: 20px; }
  .page.active { display: block; }
  .caliber-note { background: #fffbe6; border: 1px solid #ffe58f; padding: 12px 16px; margin-bottom: 20px; font-size: 13px; color: #614700; line-height:1.7; }
  .caliber-note strong { color: #d48806; }
  .kpi-row { display: grid; grid-template-columns: repeat(7, 1fr); gap: 12px; margin-bottom: 20px; }
  .kpi-row-5 { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 20px; }
  .kpi-card { background: #fff; border: 1px solid #e0e0e0; border-left: 3px solid #1890ff; padding: 12px 14px; }
  .kpi-card.success { border-left-color: #52c41a; }
  .kpi-card.warning { border-left-color: #faad14; }
  .kpi-card.danger { border-left-color: #f5222d; }
  .kpi-card.info { border-left-color: #722ed1; }
  .kpi-card .label { font-size: 12px; color: #888; margin-bottom: 6px; }
  .kpi-card .value { font-size: 20px; font-weight: 600; color: #333; }
  .kpi-card .sub { font-size: 11px; color: #999; margin-top: 4px; }
  .chart-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 16px; }
  .chart-grid-1 { display: grid; grid-template-columns: 1fr; gap: 16px; margin-bottom: 16px; }
  .chart-card { background: #fff; border: 1px solid #e0e0e0; padding: 14px 16px; }
  .chart-title { font-size: 14px; font-weight: 600; color: #333; margin-bottom: 8px; }
  .title-note { font-size: 11px; font-weight: normal; color: #722ed1; background: #f9f0ff; border: 1px solid #efdbff; padding: 1px 6px; margin-left: 8px; border-radius: 2px; vertical-align: middle; }
  .chart-desc { background: #fffbe6; border-left: 3px solid #ffd666; padding: 6px 10px; margin-bottom: 10px; font-size: 12px; color: #614700; line-height: 1.5; }
  .chart-body { width: 100%; height: 360px; }
  .chart-body.tall { height: 480px; }
  .data-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .data-table th { background: #fafafa; padding: 8px 10px; text-align: left; border-bottom: 1px solid #e0e0e0; font-weight: 500; color: #666; position: sticky; top: 0; }
  .data-table td { padding: 8px 10px; border-bottom: 1px solid #f0f0f0; }
  .data-table tr:hover td { background: #fafafa; }
  .neg { color: #f5222d; }
  .work-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
  .work-team { background: #fff; border: 1px solid #e0e0e0; border-left: 3px solid #faad14; padding: 16px 18px; margin-bottom: 16px; }
  .work-team-header { font-size: 16px; font-weight: 600; color: #d48806; padding-bottom: 8px; border-bottom: 2px solid #faad14; margin-bottom: 12px; }
  .work-team-items { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0 28px; }
  .work-col { background: #fff; border: 1px solid #e0e0e0; padding: 16px 18px; }
  .work-col-header { font-size: 16px; font-weight: 600; color: #1890ff; padding-bottom: 8px; border-bottom: 2px solid #1890ff; margin-bottom: 12px; }
  .work-col-header .role { font-size: 11px; color: #999; font-weight: normal; margin-left: 6px; }
  .work-col-header .count { float: right; font-size: 12px; color: #999; font-weight: normal; }
  .work-item { display: flex; gap: 10px; padding: 8px 0; border-bottom: 1px dashed #f0f0f0; font-size: 13px; line-height: 1.6; }
  .work-item:last-child { border-bottom: none; }
  .work-item-idx { flex: 0 0 20px; color: #1890ff; font-weight: 600; }
  .work-item-main { flex: 1; }
  .work-item-cat { color: #333; font-weight: 500; margin-bottom: 2px; }
  .work-item-desc { color: #666; }
  .work-tag { display: inline-block; font-size: 10px; padding: 1px 6px; border-radius: 2px; background: #e6f7ff; color: #1890ff; margin-left: 6px; vertical-align: middle; }
  .work-tag.ad { background: #fff7e6; color: #fa8c16; }
  .work-tag.logistics { background: #f6ffed; color: #52c41a; }
  .work-tag.festival { background: #fff1f0; color: #f5222d; }
  .work-tag.report { background: #f9f0ff; color: #722ed1; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>${config.reportHeader}</h1>
    <div class="subtitle">数据来源：${path.basename(config.excelFile)} ｜ 生成日期：${config.reportDate}</div>
  </div>
  <div class="tabs">
    <div class="tab active" onclick="switchPage('A')">口径A：商品销售额 × 商品毛利率</div>
    <div class="tab" onclick="switchPage('B')">口径B：总销售额 × 总毛利率</div>
    <div class="tab" onclick="switchPage('C')">工作内容</div>
  </div>
  <div id="pageA" class="page active">
    <div class="caliber-note">
      <strong>统计口径说明：</strong>本页数据基于 Excel sheet「${config.sheets.calibreA}」的 ${data.calibreA.details.length} 条 ASIN 明细（${config.weekRange} 全周）。
      <br>计算逻辑：销售额 = 各 ASIN 当周商品销售额之和；利润 = 商品销售额 × 商品毛利率（ASIN 级别口径）；毛利率 = 利润总额 / 销售额总额。
      <br><strong style="color:#d48806;">${monthLabel}全月利润目标完成度：</strong>${monthLabel}利润目标 ${config.monthTarget} 元，${monthLabel}全月累计利润 ${data.calibreA.monthCumProfit.toFixed(2)} 元（${monthProfitTextA}），完成度 ${data.calibreA.monthProfitPct.toFixed(2)}%。${crossMonthNote}
    </div>
    <div class="kpi-row" id="kpiRowA"></div>
    <div class="chart-grid">
      <div class="chart-card"><div class="chart-title">① 各品类销售额与利润对比</div><div class="chart-desc">双 Y 轴对比各品类的销售额（左轴）与利润（右轴）。</div><div class="chart-body tall" id="chartA1"></div></div>
      <div class="chart-card"><div class="chart-title">② 各品类销售额排名</div><div class="chart-desc">按销售额降序排列的横向条形图，条右侧标注金额。直观对比各品类销售额大小。</div><div class="chart-body tall" id="chartA2"></div></div>
    </div>
    ${data.categoryMetrics && data.categoryMetrics.length > 0 ? `
    <!-- ============ 类目运营指标：占一整行 ============ -->
    <div class="chart-card" style="margin-bottom:16px;">
      <div class="chart-title">📊 类目运营指标（四周对比）</div>
      <div class="chart-desc">从 Sheet1 提取。选一个类目 → 查看其 4 周的销量、总流量、广告曝光、广告点击变化。</div>

      <!-- 筛选器 -->
      <div id="catFilter" style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px;"></div>

      <!-- 本周 4 指标小卡 -->
      <div id="catKpi" style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:14px;"></div>

      <!-- 双图表：销量+总流量 / 点击+曝光 -->
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;">
        <div>
          <div style="font-size:12px;color:#666;margin-bottom:4px;">销量（右轴）& 总流量（左轴）</div>
          <div id="chartCatSL" style="width:100%;height:280px;"></div>
        </div>
        <div>
          <div style="font-size:12px;color:#666;margin-bottom:4px;">广告点击（右轴）& 广告曝光（左轴）</div>
          <div id="chartCatCE" style="width:100%;height:280px;"></div>
        </div>
      </div>

      <!-- 详细数据表 -->
      <div id="catDetailTable" style="margin-top:14px;max-height:220px;overflow:auto;"></div>
    </div>
    ` : ''}
    <div class="chart-grid">
      <div class="chart-card"><div class="chart-title">③ 负责人业绩对比</div><div class="chart-body" id="chartA3"></div></div>
      <div class="chart-card"><div class="chart-title">④ 负责人利润贡献占比</div><div class="chart-body" id="chartA4"></div></div>
      <div class="chart-card"><div class="chart-title">⑤ ${monthLabel}利润目标完成度（环形进度）</div><div class="chart-desc">蓝色弧长为已完成进度，灰色为剩余。${monthLabel}利润目标 ${(config.monthTarget/10000)} 万元，${monthLabel}全月累计已完成 ${(data.calibreA.monthCumProfit/10000).toFixed(2)} 万元利润，进度 ${data.calibreA.monthProfitPct.toFixed(2)}%。</div><div class="chart-body" id="chartA5"></div></div>
      <div class="chart-card"><div class="chart-title">⑥ 最近5周销售额与利润变化</div><div class="chart-desc">含本周在内最近5周的销售额与利润走势，数据取自口径A sheet 右侧的趋势记录表。</div><div class="chart-body" id="chartA10"></div></div>
      <div class="chart-card"><div class="chart-title">⑦ Top10 ASIN 销售额排名</div><div class="chart-body tall" id="chartA6"></div></div>
      <div class="chart-card"><div class="chart-title">⑧ 亏损 ASIN 清单<span class="title-note">按 4km 毛利率判定</span></div><div class="chart-desc">亏损判定与毛利率均采用 4km 口径（4km 绝对值不精确，但每周正负方向可靠）。4km 毛利率为负的 ASIN 视为亏损。</div><div class="chart-body" id="chartA7" style="height:auto; max-height:480px; overflow:auto;"></div></div>
    </div>
    <div class="chart-grid-1">
      <div class="chart-card"><div class="chart-title">⑨ 滞销产品（零销售额）分布</div><div class="chart-body" id="chartA9"></div></div>
    </div>
  </div>
  <div id="pageB" class="page">
    <div class="caliber-note">
      <strong>统计口径说明：</strong>本页数据基于 Excel sheet「${config.sheets.calibreB}」的每日数据（${config.weekRange} 共 7 天）。
      <br>计算逻辑：销售额 = 总销售额（小组/各人每日）；利润 = 总销售额 × 总毛利率；完成率 = 当日销售额 / 日均目标。
      <br><strong style="color:#d48806;">${monthLabel}全月利润目标完成度：</strong>${monthLabel}利润目标 ${config.monthTarget} 元（人民币），${monthLabel}全月累计利润 ${data.calibreB.monthCumProfit.toFixed(2)} 美元（${monthProfitTextB}），按汇率 ${data.calibreB.usdCnyRate} 换算为 ${data.calibreB.monthCumProfitCNY.toFixed(2)} 元人民币，月进度 ${data.calibreB.monthPct.toFixed(2)}%。${crossMonthNote}
      <br><strong style="color:#d48806;">单位说明：</strong>本页所有金额数据单位为 <strong>美元（USD）</strong>，与口径A（人民币）不同，请勿直接对比数值大小。
    </div>
    <div class="kpi-row-5" id="kpiRowB"></div>
    <div class="chart-grid">
      <div class="chart-card"><div class="chart-title">⑩ 小组每日销售额与利润趋势</div><div class="chart-body" id="chartB1"></div></div>
      <div class="chart-card"><div class="chart-title">⑪ 小组每日完成率趋势</div><div class="chart-desc">${config.chartB2Desc}</div><div class="chart-body" id="chartB2"></div></div>
      <div class="chart-card"><div class="chart-title">⑫ 各人员每日销售额对比</div><div class="chart-body" id="chartB3"></div></div>
      <div class="chart-card"><div class="chart-title">⑬ 各人员每日完成率对比</div><div class="chart-desc">100% 为达标基准线。完成率持续偏高者目标可上调，多数未达标者目标可下调，辅助调整目标值。</div><div class="chart-body" id="chartB4"></div></div>
      <div class="chart-card"><div class="chart-title">⑭ ${monthLabel}利润目标完成度（环形进度）</div><div class="chart-desc">蓝色弧长为已完成进度，灰色为剩余。${monthLabel}利润目标 50 万元人民币，${monthLabel}全月累计利润换算后为 ${(data.calibreB.monthCumProfitCNY/10000).toFixed(2)} 万元，进度 ${data.calibreB.monthPct.toFixed(2)}%。</div><div class="chart-body" id="chartB5"></div></div>
      <div class="chart-card"><div class="chart-title">⑮ 人员销售额占比 vs 利润占比</div><div class="chart-desc">利润占比 &gt; 销售额占比说明该人产品毛利率更高，反之说明毛利率偏低。可据此识别高毛利/低毛利贡献者。</div><div class="chart-body" id="chartB6"></div></div>
    </div>
  </div>
  <div id="pageC" class="page">
    <div class="caliber-note">
      <strong>工作内容说明：</strong>本页展示负责人本周工作内容（已按「原文 → 精简标题；分类标签」整理）。每条含精简标题与一个或多个分类标签。
      <br>数据来源：${path.basename(config.excelFile)} → sheet「${config.sheets.workContent}」。
      <br>标签分类：<span class="work-tag">默认</span><span class="work-tag ad">广告</span><span class="work-tag logistics">物流</span><span class="work-tag festival">节日营销</span><span class="work-tag report">汇报</span>
    </div>
    <div id="teamWorkBox"></div>
    <div class="work-grid" id="workGrid"></div>
  </div>
</div>
<script>
var DATA = ${dataStr};
${renderScripts()}
</script>
</body>
</html>`;

function renderScripts() {
  var workContentStr = JSON.stringify(WORK_CONTENT);
  return `
function fmtMoney(v){ if(v>=10000) return (v/10000).toFixed(2)+'万'; return v.toFixed(2); }
function fmtPct(v){ return (v*100).toFixed(2)+'%'; }

${renderCategoryScripts()}

function switchPage(page){
  var pages=['A','B','C'];
  document.querySelectorAll('.tab').forEach((t,i)=>{ t.classList.toggle('active', page===pages[i]); });
  document.getElementById('pageA').classList.toggle('active', page==='A');
  document.getElementById('pageB').classList.toggle('active', page==='B');
  document.getElementById('pageC').classList.toggle('active', page==='C');
  if(page==='A') renderKpiA();
  else if(page==='B') renderKpiB();
  requestAnimationFrame(()=>{
    if(page==='A') renderChartsA();
    else if(page==='B') renderChartsB();
    else renderWorkContent();
    requestAnimationFrame(()=>{ window.dispatchEvent(new Event('resize')); });
  });
}

function kpiCard(label, value, sub, cls){
  return '<div class="kpi-card '+(cls||'')+'"><div class="label">'+label+'</div><div class="value">'+value+'</div>'+(sub?'<div class="sub">'+sub+'</div>':'')+'</div>';
}

function renderKpiA(){
  var totalSales = DATA.calibreA.totalSales, totalProfit = DATA.calibreA.totalProfit;
  var margin = totalProfit/totalSales;
  var details = DATA.calibreA.details;
  var activeCount=0, lossCount=0, lossBase=0;
  var capMargins = [];
  details.forEach(d=>{
    if(d.sales>0) activeCount++;
    if(d.margin4km!=null){ lossBase++; if(d.margin4km<0) lossCount++; }  // 与图⑧一致：按 4km 毛利率判定
    if(d.marginCaptain!=null) capMargins.push(d.marginCaptain);
  });
  var avgCap = capMargins.length ? capMargins.reduce((a,b)=>a+b,0)/capMargins.length : 0.10;
  var monthPct = DATA.calibreA.monthProfitPct;
  var salesWoW = DATA.calibreA.salesWoW, profitWoW = DATA.calibreA.profitWoW;
  var salesWoWStr = (salesWoW>=0?'+':'')+salesWoW.toFixed(2)+'%';
  var profitWoWStr = (profitWoW>=0?'+':'')+profitWoW.toFixed(2)+'%';
  var html = '';
  html += kpiCard('本周总销售额', fmtMoney(totalSales), '环比 '+salesWoWStr, salesWoW>=0?'success':'danger');
  html += kpiCard('本周总利润', fmtMoney(totalProfit), '环比 '+profitWoWStr, profitWoW>=0?'success':'danger');
  html += kpiCard('整体毛利率', fmtPct(margin), '利润/销售额', 'info');
  html += kpiCard('有动销 ASIN 数', activeCount+' 个', '总 '+details.length+' 个', '');
  html += kpiCard('亏损 ASIN 数', lossCount+' 个', '4km 口径，可判定 '+lossBase+'/'+details.length+' 个', 'danger');
  html += kpiCard('平均船长毛利率', fmtPct(avgCap), 'ASIN 维度均值', 'info');
  html += kpiCard('月利润目标完成度', monthPct.toFixed(2)+'%', '本月累计 '+fmtMoney(DATA.calibreA.monthCumProfit)+' / 50万', 'warning');
  document.getElementById('kpiRowA').innerHTML = html;
}

function renderKpiB(){
  var totalSales = DATA.calibreB.totalSales, totalProfit = DATA.calibreB.totalProfit;
  var avgDaily = totalSales/7;
  var notMet = 0;
  DATA.calibreB.groupDaily.forEach(d=>{ if(d.completion<1) notMet++; });
  var monthPct = DATA.calibreB.monthPct;
  var salesWoW = DATA.calibreB.salesWoW, profitWoW = DATA.calibreB.profitWoW;
  var salesWoWStr = (salesWoW>=0?'+':'')+salesWoW.toFixed(2)+'%';
  var profitWoWStr = (profitWoW>=0?'+':'')+profitWoW.toFixed(2)+'%';
  var html = '';
  html += kpiCard('月利润目标完成度', monthPct.toFixed(2)+'%', '本月累计 '+(DATA.calibreB.monthCumProfitCNY/10000).toFixed(2)+' 万 CNY', 'warning');
  html += kpiCard('本周总销售额 (USD)', fmtMoney(totalSales), '环比 '+salesWoWStr, salesWoW>=0?'success':'danger');
  html += kpiCard('本周总利润 (USD)', fmtMoney(totalProfit), '环比 '+profitWoWStr, profitWoW>=0?'success':'danger');
  html += kpiCard('未达标天数', notMet+' 天', '7 天中', 'danger');
  html += kpiCard('日均销售额 (USD)', fmtMoney(avgDaily), '小组口径', '');
  document.getElementById('kpiRowB').innerHTML = html;
}

function chartA1(){
  var cats = DATA.calibreA.categories;
  var ec = echarts.init(document.getElementById('chartA1'));
  ec.setOption({
    tooltip:{trigger:'axis',axisPointer:{type:'shadow'},formatter:function(p){var s=p[0].name+'<br/>';p.forEach(function(x){s+=x.marker+x.seriesName+': '+x.value.toFixed(2)+'元<br/>';});return s;}},
    legend:{data:['销售额','利润'],top:0},
    grid:{left:65,right:55,bottom:105,top:60},
    xAxis:{type:'category',data:cats.map(c=>c.name),axisLabel:{rotate:45,fontSize:11}},
    yAxis:[{type:'value',name:'销售额',axisLabel:{formatter:function(v){return (v/10000).toFixed(2)+'万';}}},
         {type:'value',name:'利润',axisLabel:{formatter:function(v){return (v/10000).toFixed(2)+'万';}}}],
    series:[
      {name:'销售额',type:'bar',data:cats.map(c=>c.sales),itemStyle:{color:'#5470c6'}},
      {name:'利润',type:'bar',yAxisIndex:1,data:cats.map(c=>c.profit),itemStyle:{color:'#91cc75'}}
    ]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartA2(){
  // 横向条形图：品类名在左轴，金额标签在条右侧，彻底避免标签与品类名争位压叠
  var cats = DATA.calibreA.categories.slice().sort((a,b)=>b.sales-a.sales).reverse();
  var ec = echarts.init(document.getElementById('chartA2'));
  ec.setOption({
    tooltip:{trigger:'axis',axisPointer:{type:'shadow'},formatter:function(p){
      return p[0].name+'<br/>销售额: '+(p[0].value/10000).toFixed(2)+'万元';
    }},
    grid:{left:115,right:85,bottom:20,top:20},
    xAxis:{type:'value',axisLabel:{formatter:function(v){return (v/10000).toFixed(2)+'万';},fontSize:9}},
    yAxis:{type:'category',data:cats.map(c=>c.name),axisLabel:{fontSize:10}},
    series:[{
      type:'bar',data:cats.map(c=>c.sales),itemStyle:{color:'#5470c6'},barCategoryGap:'40%',
      label:{show:true,position:'right',distance:5,fontSize:10,formatter:function(p){return (p.value/10000).toFixed(2)+'万';}}
    }]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartA3(){
  var p = DATA.calibreA.personnel;
  var ec = echarts.init(document.getElementById('chartA3'));
  ec.setOption({
    tooltip:{trigger:'axis',formatter:function(p){var s=p[0].name+'<br/>';p.forEach(function(x){s+=x.marker+x.seriesName+': '+x.value.toFixed(2)+'<br/>';});return s;}},
    legend:{data:['销售额','利润'],top:0},
    grid:{left:60,right:40,bottom:40,top:40},
    xAxis:{type:'category',data:p.map(x=>x.name)},
    yAxis:[{type:'value',name:'销售额',axisLabel:{formatter:function(v){return (v/10000).toFixed(2)+'万';}}},
         {type:'value',name:'利润',axisLabel:{formatter:function(v){return (v/10000).toFixed(2)+'万';}}}],
    series:[
      {name:'销售额',type:'bar',data:p.map(x=>x.sales),itemStyle:{color:'#5470c6'},
       label:{show:true,position:'top',formatter:function(p){return (p.value/10000).toFixed(2)+'万';}}},
      {name:'利润',type:'bar',yAxisIndex:1,data:p.map(x=>x.profit),itemStyle:{color:'#91cc75'},
       label:{show:true,position:'top',formatter:function(p){return (p.value/10000).toFixed(2)+'万';}}}
    ]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartA4(){
  var p = DATA.calibreA.personnel;
  var ec = echarts.init(document.getElementById('chartA4'));
  ec.setOption({
    tooltip:{trigger:'item',formatter:function(p){return p.name+': '+p.value.toFixed(2)+'元 ('+p.percent.toFixed(2)+'%)';}},
    legend:{bottom:0},
    series:[{
      type:'pie',radius:['40%','65%'],center:['50%','45%'],
      data:p.map(x=>({name:x.name,value:x.profit})),
      label:{formatter:function(p){return p.name+'\\n'+p.percent.toFixed(2)+'%';}}
    }]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartA5(){
  var monthCumProfit = DATA.calibreA.monthCumProfit;
  var monthTarget = DATA.calibreA.monthProfitTarget;
  var pct = monthCumProfit/monthTarget*100;
  var ec = echarts.init(document.getElementById('chartA5'));
  ec.setOption({
    series:[{
      type:'pie',radius:['62%','82%'],center:['50%','50%'],startAngle:90,silent:true,
      label:{show:false},labelLine:{show:false},
      data:[
        {value:pct, name:'已完成', itemStyle:{color:'#1890ff'}},
        {value:100-pct, name:'剩余', itemStyle:{color:'#f0f0f0'}}
      ]
    }],
    graphic:[
      {type:'text', left:'center', top:'38%', style:{text:pct.toFixed(2)+'%', fontSize:42, fontWeight:'bold', fill:'#1890ff', textAlign:'center'}},
      {type:'text', left:'center', top:'60%', style:{text:'月利润目标完成度', fontSize:14, fill:'#999', textAlign:'center'}},
      {type:'text', left:'center', top:'70%', style:{text:'本月累计 '+(DATA.calibreA.monthCumProfit/10000).toFixed(2)+' 万 RMB 利润 / 目标 50 万', fontSize:11, fill:'#bbb', textAlign:'center'}}
    ]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartATrend(){
  var trend = DATA.calibreA.weeklyTrend || [];
  var sData = trend.map(t=>t.sales), pData = trend.map(t=>t.profit);
  var pos = splitLabelPos(sData, pData);
  var ec = echarts.init(document.getElementById('chartA10'));
  ec.setOption({
    tooltip:{trigger:'axis',formatter:function(p){var s=p[0].name+'<br/>';p.forEach(function(x){s+=x.marker+x.seriesName+': '+(x.value/10000).toFixed(2)+'万元<br/>';});return s;}},
    legend:{data:['销售额','利润'],top:0},
    grid:{left:70,right:70,bottom:40,top:40},
    xAxis:{type:'category',data:trend.map(t=>t.week)},
    yAxis:[{type:'value',name:'销售额',axisLabel:{formatter:function(v){return (v/10000).toFixed(2)+'万';}}},
         {type:'value',name:'利润',axisLabel:{formatter:function(v){return (v/10000).toFixed(2)+'万';}}}],
    series:[
      {name:'销售额',type:'line',data:toLabeledData(sData,pos.pa),smooth:true,itemStyle:{color:'#5470c6'},
       label:{show:true,distance:6,fontSize:10,formatter:function(p){return (p.value/10000).toFixed(2)+'万';}},labelLayout:{moveOverlap:'shiftY'}},
      {name:'利润',type:'line',yAxisIndex:1,data:toLabeledData(pData,pos.pb),smooth:true,itemStyle:{color:'#91cc75'},
       label:{show:true,distance:6,fontSize:10,formatter:function(p){return (p.value/10000).toFixed(2)+'万';}},labelLayout:{moveOverlap:'shiftY'}}
    ]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartA6(){
  var top10 = DATA.calibreA.details.slice().sort((a,b)=>b.sales-a.sales).slice(0,10);
  var ec = echarts.init(document.getElementById('chartA6'));
  ec.setOption({
    tooltip:{trigger:'axis',axisPointer:{type:'shadow'}},
    grid:{left:140,right:120,bottom:40,top:30},
    xAxis:{type:'value',axisLabel:{formatter:function(v){return (v/10000).toFixed(2)+'万';}}},
    yAxis:{type:'category',data:top10.map(d=>d.asin+' ('+d.person+')').reverse()},
    series:[{
      type:'bar',data:top10.map(d=>d.sales).reverse(),itemStyle:{color:'#5470c6'},
      label:{show:true,position:'right',formatter:function(p){
        var d=top10[top10.length-1-p.dataIndex];
        return d.category+' '+p.value.toFixed(0)+'元';
      }}
    }]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartA7(){
  // 亏损判定与展示均用 4km 毛利率（4km 数值不精确但正负可靠）
  var loss = DATA.calibreA.details
    .filter(d=>d.margin4km!==null && d.margin4km<0)
    .sort((a,b)=>a.margin4km-b.margin4km);
  if(loss.length===0){
    document.getElementById('chartA7').innerHTML = '<div style="padding:24px;text-align:center;color:#999;font-size:13px;">本周无 4km 毛利率为负的 ASIN</div>';
    return;
  }
  var html = '<table class="data-table"><thead><tr><th>负责人</th><th>品类</th><th>ASIN</th><th>销售额</th><th>4km 毛利率</th></tr></thead><tbody>';
  loss.forEach(d=>{
    html += '<tr><td>'+d.person+'</td><td>'+d.category+'</td><td>'+d.asin+'</td>'
      +'<td>'+d.sales.toFixed(2)+'</td>'
      +'<td class="neg">'+(d.margin4km*100).toFixed(2)+'%</td></tr>';
  });
  html += '</tbody></table>';
  document.getElementById('chartA7').innerHTML = html;
}

function chartA9(){
  var zero = DATA.calibreA.details.filter(d=>d.sales===0);
  var persons = DATA.calibreA.personnel.map(p=>p.name);
  var categories = [...new Set(zero.map(d=>d.category))];
  var series = persons.map(p=>({name:p, type:'bar', stack:'total',data:categories.map(c=>zero.filter(d=>d.person===p && d.category===c).length)}));
  var ec = echarts.init(document.getElementById('chartA9'));
  ec.setOption({
    tooltip:{trigger:'axis',axisPointer:{type:'shadow'}},
    legend:{top:0},
    grid:{left:60,right:40,bottom:60,top:40},
    xAxis:{type:'category',data:categories,axisLabel:{rotate:30}},
    yAxis:{type:'value',name:'ASIN 数'},
    series:series
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartB1(){
  var d = DATA.calibreB.groupDaily;
  var ec = echarts.init(document.getElementById('chartB1'));
  ec.setOption({
    tooltip:{trigger:'axis',formatter:function(p){var s=p[0].name+'<br/>';p.forEach(function(x){s+=x.marker+x.seriesName+': '+x.value.toFixed(2)+'<br/>';});return s;}},
    legend:{data:['销售额','利润'],top:0},
    grid:{left:60,right:50,bottom:40,top:40},
    xAxis:{type:'category',data:d.map(x=>x.date)},
    yAxis:[{type:'value',name:'销售额'},{type:'value',name:'利润'}],
    series:[
      {name:'销售额',type:'line',data:d.map(x=>x.sales),smooth:true,itemStyle:{color:'#5470c6'},label:{show:true,formatter:function(p){return p.value.toFixed(2);}}},
      {name:'利润',type:'line',yAxisIndex:1,data:d.map(x=>x.profit),smooth:true,itemStyle:{color:'#91cc75'}}
    ]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartB2(){
  var d = DATA.calibreB.groupDaily;
  var ec = echarts.init(document.getElementById('chartB2'));
  ec.setOption({
    tooltip:{trigger:'axis',formatter:function(p){return p[0].axisValue+'<br/>完成率: '+(p[0].value*100).toFixed(1)+'%';}},
    grid:{left:60,right:40,bottom:40,top:30},
    xAxis:{type:'category',data:d.map(x=>x.date)},
    yAxis:{type:'value',name:'完成率',axisLabel:{formatter:function(v){return (v*100).toFixed(0)+'%';}}},
    series:[{
      type:'line',data:d.map(x=>x.completion),smooth:true,itemStyle:{color:'#ee6666'},
      markLine:{data:[{yAxis:1,name:'达标基准'}],lineStyle:{color:'#52c41a',type:'dashed'}}
    }]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartB3(){
  var dates = DATA.calibreB.groupDaily.map(x=>x.date);
  var series = [
    {name:'高杰',data:DATA.calibreB.gaojieDaily.map(x=>x.sales)},
    {name:'郑春燕',data:DATA.calibreB.zhengchunyanDaily.map(x=>x.sales)},
    {name:'张志鹏',data:DATA.calibreB.zhangzhipengDaily.map(x=>x.sales)},
    {name:'李燕',data:DATA.calibreB.liyanDaily.map(x=>x.sales)}
  ].map(s=>({...s,type:'line',smooth:true}));
  var ec = echarts.init(document.getElementById('chartB3'));
  ec.setOption({
    tooltip:{trigger:'axis',formatter:function(p){var s=p[0].name+'<br/>';p.forEach(function(x){s+=x.marker+x.seriesName+': '+x.value.toFixed(2)+'<br/>';});return s;}},legend:{top:0},
    grid:{left:60,right:40,bottom:40,top:40},
    xAxis:{type:'category',data:dates},yAxis:{type:'value',name:'销售额'},series:series
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartB4(){
  var dates = DATA.calibreB.groupDaily.map(x=>x.date);
  var series = [
    {name:'高杰',data:DATA.calibreB.gaojieDaily.map(x=>x.completion)},
    {name:'郑春燕',data:DATA.calibreB.zhengchunyanDaily.map(x=>x.completion)},
    {name:'张志鹏',data:DATA.calibreB.zhangzhipengDaily.map(x=>x.completion)},
    {name:'李燕',data:DATA.calibreB.liyanDaily.map(x=>x.completion)}
  ].map(s=>({...s,type:'line',smooth:true}));
  var ec = echarts.init(document.getElementById('chartB4'));
  ec.setOption({
    tooltip:{trigger:'axis',formatter:function(p){var s=p[0].axisValue+'<br/>';p.forEach(x=>{s+=x.marker+x.seriesName+': '+(x.value*100).toFixed(1)+'%<br/>';});return s;}},
    legend:{top:0},
    grid:{left:60,right:40,bottom:40,top:40},
    xAxis:{type:'category',data:dates},yAxis:{type:'value',name:'完成率',axisLabel:{formatter:function(v){return (v*100).toFixed(0)+'%';}}},
    series:series,markLine:{symbol:'none',data:[{yAxis:1}],lineStyle:{color:'#52c41a',type:'dashed'}}
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartB5(){
  var pct = DATA.calibreB.monthPct;
  var ec = echarts.init(document.getElementById('chartB5'));
  ec.setOption({
    series:[{
      type:'pie',radius:['62%','82%'],center:['50%','50%'],startAngle:90,silent:true,
      label:{show:false},labelLine:{show:false},
      data:[
        {value:pct, name:'已完成', itemStyle:{color:'#1890ff'}},
        {value:100-pct, name:'剩余', itemStyle:{color:'#f0f0f0'}}
      ]
    }],
    graphic:[
      {type:'text', left:'center', top:'38%', style:{text:pct.toFixed(2)+'%', fontSize:42, fontWeight:'bold', fill:'#1890ff', textAlign:'center'}},
      {type:'text', left:'center', top:'60%', style:{text:'月利润目标完成度', fontSize:14, fill:'#999', textAlign:'center'}},
      {type:'text', left:'center', top:'70%', style:{text:'本月累计 '+(DATA.calibreB.monthCumProfitCNY/10000).toFixed(2)+' 万 CNY / 月利润目标 50万', fontSize:11, fill:'#bbb', textAlign:'center'}}
    ]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function chartB6(){
  var persons = ['高杰','郑春燕','张志鹏','李燕'];
  var totalSales = DATA.calibreB.totalSales, totalProfit = DATA.calibreB.totalProfit;
  var salesShare = [
    DATA.calibreB.gaojieDaily.reduce((s,x)=>s+x.sales,0)/totalSales,
    DATA.calibreB.zhengchunyanDaily.reduce((s,x)=>s+x.sales,0)/totalSales,
    DATA.calibreB.zhangzhipengDaily.reduce((s,x)=>s+x.sales,0)/totalSales,
    DATA.calibreB.liyanDaily.reduce((s,x)=>s+x.sales,0)/totalSales
  ];
  var profitShare = [
    DATA.calibreB.gaojieDaily.reduce((s,x)=>s+x.profit,0)/totalProfit,
    DATA.calibreB.zhengchunyanDaily.reduce((s,x)=>s+x.profit,0)/totalProfit,
    DATA.calibreB.zhangzhipengDaily.reduce((s,x)=>s+x.profit,0)/totalProfit,
    DATA.calibreB.liyanDaily.reduce((s,x)=>s+x.profit,0)/totalProfit
  ];
  var ec = echarts.init(document.getElementById('chartB6'));
  ec.setOption({
    tooltip:{trigger:'axis',axisPointer:{type:'shadow'},formatter:function(p){var s=p[0].axisValue+'<br/>';p.forEach(x=>{s+=x.marker+x.seriesName+': '+(x.value).toFixed(1)+'%<br/>';});return s;}},
    legend:{data:['销售额占比','利润占比'],top:0},
    grid:{left:60,right:40,bottom:40,top:40},
    xAxis:{type:'category',data:persons},yAxis:{type:'value',axisLabel:{formatter:'{value}%'}},
    series:[
      {name:'销售额占比',type:'bar',data:salesShare.map(v=>(v*100).toFixed(2)*1),itemStyle:{color:'#5470c6'},label:{show:true,formatter:function(p){return p.value.toFixed(1)+'%';}}},
      {name:'利润占比',type:'bar',data:profitShare.map(v=>(v*100).toFixed(2)*1),itemStyle:{color:'#91cc75'},label:{show:true,formatter:function(p){return p.value.toFixed(1)+'%';}}}
    ]
  });
  window.addEventListener('resize',()=>ec.resize());
}

function renderChartsA(){ chartA1();chartA2();chartA3();chartA4();chartA5();chartATrend();chartA6();chartA7();chartA9(); if(CAT_METRICS.length>0){renderCatFilter();renderCatKpi();renderCatCharts();renderCatTable();} }
function renderChartsB(){ chartB1();chartB2();chartB3();chartB4();chartB5();chartB6(); }

var WORK_CONTENT = ${workContentStr};
var TEAM_WORK = ${JSON.stringify(data.teamWork || null)};
var TAG_LABELS = { '':'默认', ad:'广告', logistics:'物流', festival:'节日营销', report:'汇报' };

function workTagHtml(it){
  var tags = (it.tags && it.tags.length) ? it.tags : [''];
  return tags.map(function(t){
    return '<span class="work-tag'+(t?' '+t:'')+'">'+(TAG_LABELS[t]||'默认')+'</span>';
  }).join('');
}

function renderWorkContent(){
  var html = '';
  WORK_CONTENT.forEach(function(p){
    html += '<div class="work-col">';
    html += '<div class="work-col-header">'+p.name+'<span class="role">'+(p.role||'运营')+'</span><span class="count">'+p.items.length+' 项</span></div>';
    p.items.forEach(function(it, i){
      html += '<div class="work-item"><div class="work-item-idx">'+(i+1)+'</div><div class="work-item-main">';
      html += '<div class="work-item-cat">'+it.cat+workTagHtml(it)+'</div>';
      html += '<div class="work-item-desc">'+it.desc+'</div>';
      html += '</div></div>';
    });
    html += '</div>';
  });
  document.getElementById('workGrid').innerHTML = html;

  // 小组工作事项：单独一行，位于成员四列之上
  if (TEAM_WORK && TEAM_WORK.items && TEAM_WORK.items.length) {
    var tHtml = '<div class="work-team">';
    tHtml += '<div class="work-team-header">'+TEAM_WORK.name+'<span class="count">'+TEAM_WORK.items.length+' 项</span></div>';
    tHtml += '<div class="work-team-items">';
    TEAM_WORK.items.forEach(function(it, i){
      tHtml += '<div class="work-item"><div class="work-item-idx">'+(i+1)+'</div><div class="work-item-main">';
      tHtml += '<div class="work-item-cat">'+it.cat+workTagHtml(it)+'</div>';
      tHtml += '<div class="work-item-desc">'+it.desc+'</div>';
      tHtml += '</div></div>';
    });
    tHtml += '</div></div>';
    document.getElementById('teamWorkBox').innerHTML = tHtml;
  }
}

renderKpiA(); renderChartsA();
`;
}

// 类目运营指标模块：返回浏览器端 JS 代码（不用反引号，避免与 renderScripts 的 T2 冲突）
function renderCategoryScripts() {
  const cm = JSON.stringify(data.categoryMetrics);
  const cn = JSON.stringify(data.categoryNames);
  return [
    "var CAT_METRICS = " + cm + ";",
    "var CAT_WEEKS = CAT_METRICS.map(function(m){ return m.week; });",
    "var CAT_NAMES = " + cn + ";",
    "var currentCatIndex = 0;",
    "",
    "// 逐点决定双线标签的上下位置：按各自序列最大值占比近似像素高度，高点的标签放上、低点的放下",
    "// 解决两条线交叉或贴近时标签挤在同一缝隙的问题；零值点贴底，标签一律放上方避免出界",
    "function splitLabelPos(a, b) {",
    "  var aMax = Math.max.apply(null, a) || 1;",
    "  var bMax = Math.max.apply(null, b) || 1;",
    "  var pa = [], pb = [];",
    "  for (var i = 0; i < a.length; i++) {",
    "    if (a[i] === 0 || b[i] === 0) { pa.push('top'); pb.push('top'); continue; }",
    "    var aHigher = a[i] / aMax >= b[i] / bMax;",
    "    pa.push(aHigher ? 'top' : 'bottom');",
    "    pb.push(aHigher ? 'bottom' : 'top');",
    "  }",
    "  return { pa: pa, pb: pb };",
    "}",
    "function toLabeledData(arr, pos) {",
    "  return arr.map(function(v, i) { return { value: v, label: { position: pos[i] } }; });",
    "}",
    "",
    "function getCatSeries(catName) {",
    "  return CAT_METRICS.map(function(m) {",
    "    var c = m.categories.find(function(x){ return x.name === catName; });",
    "    return c || { traffic:0, exposure:0, clicks:0, sales:0 };",
    "  });",
    "}",
    "",
    "function renderCatFilter() {",
    "  var container = document.getElementById('catFilter');",
    "  if (!container || CAT_NAMES.length === 0) return;",
    "  container.innerHTML = CAT_NAMES.map(function(name, i) {",
    "    var active = i === currentCatIndex;",
    "    return '<button onclick=\"selectCat(' + i + ')\" style=\"padding:6px 14px;border:1px solid ' + (active ? '#1890ff' : '#d9d9d9') + ';background:' + (active ? '#1890ff' : '#fff') + ';color:' + (active ? '#fff' : '#666') + ';border-radius:16px;cursor:pointer;font-size:12px;\">' + name + '</button>';",
    "  }).join('');",
    "}",
    "",
    "function selectCat(i) {",
    "  currentCatIndex = i;",
    "  renderCatFilter();",
    "  renderCatKpi();",
    "  renderCatCharts();",
    "  renderCatTable();",
    "}",
    "",
    "function renderCatKpi() {",
    "  var container = document.getElementById('catKpi');",
    "  if (!container || CAT_NAMES.length === 0) return;",
    "  var cat = CAT_NAMES[currentCatIndex];",
    "  var series = getCatSeries(cat);",
    "  var cur = series[series.length - 1];",
    "  var prev = series[series.length - 2] || cur;",
    "  function delta(curV, prevV) {",
    "    if (prevV === 0) return { pct: 0, up: true };",
    "    var pct = (curV - prevV) / prevV * 100;",
    "    return { pct: pct, up: pct >= 0 };",
    "  }",
    "  function fmt(n) { return (n >= 10000 ? (n/10000).toFixed(1)+'万' : Math.round(n)).toLocaleString(); }",
    "  var items = [",
    "    { label: '本周销量', val: fmt(cur.sales), d: delta(cur.sales, prev.sales) },",
    "    { label: '本周总流量', val: fmt(cur.traffic), d: delta(cur.traffic, prev.traffic) },",
    "    { label: '本周广告曝光', val: fmt(cur.exposure), d: delta(cur.exposure, prev.exposure) },",
    "    { label: '本周广告点击', val: fmt(cur.clicks), d: delta(cur.clicks, prev.clicks) }",
    "  ];",
    "  container.innerHTML = items.map(function(x) {",
    "    return '<div style=\"background:#fafafa;border:1px solid #e0e0e0;padding:10px 14px;\">' +",
    "      '<div style=\"font-size:11px;color:#999;margin-bottom:4px;\">' + x.label + '</div>' +",
    "      '<div style=\"font-size:18px;font-weight:600;color:#333;\">' + x.val + '</div>' +",
    "      '<div style=\"font-size:11px;margin-top:2px;color:' + (x.d.up ? '#52c41a' : '#f5222d') + ';\">' +",
    "        (x.d.up ? '▲' : '▼') + ' ' + Math.abs(x.d.pct).toFixed(1) + '%（环比上周）' +",
    "      '</div>' +",
    "    '</div>';",
    "  }).join('');",
    "}",
    "",
    "function renderCatCharts() {",
    "  if (CAT_NAMES.length === 0) return;",
    "  var cat = CAT_NAMES[currentCatIndex];",
    "  var series = getCatSeries(cat);",
    "  var weeks = CAT_WEEKS;",
    "  var sData = series.map(function(s){ return s.sales; });",
    "  var tData = series.map(function(s){ return s.traffic; });",
    "  var posSL = splitLabelPos(sData, tData);",
    "  var ecSL = echarts.init(document.getElementById('chartCatSL'));",
    "  ecSL.setOption({",
    "    tooltip: { trigger: 'axis' },",
    "    legend: { data: ['销量', '总流量'], bottom: 0, right: 'center' },",
    "    grid: { left: 60, right: 60, bottom: 58, top: 36 },",
    "    xAxis: { type: 'category', data: weeks },",
    "    yAxis: [",
    "      { type: 'value', name: '总流量', splitLine: { lineStyle: { type: 'dashed' } } },",
    "      { type: 'value', name: '销量', splitLine: { show: false } }",
    "    ],",
    "    series: [",
    "      { name: '销量', type: 'line', yAxisIndex: 1, color: '#1890ff', symbolSize: 8, data: toLabeledData(sData, posSL.pa), label: { show: true, distance: 6, fontSize: 10 }, labelLayout: { moveOverlap: 'shiftY' } },",
    "      { name: '总流量', type: 'line', yAxisIndex: 0, color: '#52c41a', symbolSize: 8, data: toLabeledData(tData, posSL.pb), label: { show: true, distance: 6, fontSize: 10 }, labelLayout: { moveOverlap: 'shiftY' } }",
    "    ]",
    "  });",
    "  window.addEventListener('resize', function(){ ecSL.resize(); });",
    "  var cData = series.map(function(s){ return s.clicks; });",
    "  var eData = series.map(function(s){ return s.exposure; });",
    "  var posCE = splitLabelPos(cData, eData);",
    "  var ecCE = echarts.init(document.getElementById('chartCatCE'));",
    "  ecCE.setOption({",
    "    tooltip: { trigger: 'axis' },",
    "    legend: { data: ['广告点击', '广告曝光'], bottom: 0, right: 'center' },",
    "    grid: { left: 70, right: 60, bottom: 58, top: 36 },",
    "    xAxis: { type: 'category', data: weeks },",
    "    yAxis: [",
    "      { type: 'value', name: '广告曝光', splitLine: { lineStyle: { type: 'dashed' } }, axisLabel: { formatter: function(v){ return v >= 1000 ? (v/1000)+'k' : v; } } },",
    "      { type: 'value', name: '广告点击', splitLine: { show: false } }",
    "    ],",
    "    series: [",
    "      { name: '广告点击', type: 'line', yAxisIndex: 1, color: '#faad14', symbolSize: 8, data: toLabeledData(cData, posCE.pa), label: { show: true, distance: 6, fontSize: 10 }, labelLayout: { moveOverlap: 'shiftY' } },",
    "      { name: '广告曝光', type: 'line', yAxisIndex: 0, color: '#722ed1', symbolSize: 8, data: toLabeledData(eData, posCE.pb), label: { show: true, distance: 6, fontSize: 10, formatter: function(p){ return p.value >= 1000 ? (p.value/1000).toFixed(1)+'k' : p.value; } }, labelLayout: { moveOverlap: 'shiftY' } }",
    "    ]",
    "  });",
    "  window.addEventListener('resize', function(){ ecCE.resize(); });",
    "}",
    "",
    "function renderCatTable() {",
    "  var container = document.getElementById('catDetailTable');",
    "  if (!container || CAT_NAMES.length === 0) return;",
    "  var cat = CAT_NAMES[currentCatIndex];",
    "  var series = getCatSeries(cat);",
    "  var weeks = CAT_WEEKS;",
    "  var lastIdx = series.length - 1;",
    "  function delta(cur, prev) {",
    "    if (prev === 0) return '-';",
    "    var pct = (cur - prev) / prev * 100;",
    "    return (pct >= 0 ? '▲' : '▼') + ' ' + Math.abs(pct).toFixed(1) + '%';",
    "  }",
    "  var headers = '<tr><th>指标</th>' + weeks.map(function(w){ return '<th style=\"text-align:center;\">' + w + '</th>'; }).join('') + '<th style=\"text-align:center;\">本周环比</th><th style=\"text-align:center;\">4周合计</th></tr>';",
    "  var rows = [];",
    "  var rowDefs = [",
    "    { name: '销量（件）', key: 'sales' },",
    "    { name: '总流量', key: 'traffic' },",
    "    { name: '广告曝光', key: 'exposure' },",
    "    { name: '广告点击', key: 'clicks' },",
    "    { name: '广告点击率', key: 'ctr', isPct: true }",
    "  ];",
    "  rowDefs.forEach(function(r) {",
    "    if (r.isPct) {",
    "      var vals = series.map(function(s){ return s.exposure > 0 ? (s.clicks / s.exposure * 100) : 0; });",
    "      var cur = vals[lastIdx], prev = vals[lastIdx - 1] || cur;",
    "      var pctDelta = prev === 0 ? '-' : ((cur - prev)).toFixed(2) + ' pp';",
    "      rows.push('<tr><td>' + r.name + '</td>' + vals.map(function(v){ return '<td style=\"text-align:center;\">' + v.toFixed(2) + '%</td>'; }).join('') +",
    "        '<td style=\"text-align:center;color:' + (cur >= prev ? '#52c41a' : '#f5222d') + ';\">' + (cur >= prev ? '▲' : '▼') + ' ' + pctDelta + '</td>' +",
    "        '<td style=\"text-align:center;\">-</td></tr>');",
    "    } else {",
    "      var vals = series.map(function(s){ return s[r.key]; });",
    "      var cur = vals[lastIdx], prev = vals[lastIdx - 1] || cur;",
    "      var sum = vals.reduce(function(a, b){ return a + b; }, 0);",
    "      rows.push('<tr><td>' + r.name + '</td>' + vals.map(function(v){ return '<td style=\"text-align:center;\">' + v.toLocaleString() + '</td>'; }).join('') +",
    "        '<td style=\"text-align:center;color:' + (cur >= prev ? '#52c41a' : '#f5222d') + ';\">' + delta(cur, prev) + '</td>' +",
    "        '<td style=\"text-align:center;font-weight:500;\">' + sum.toLocaleString() + '</td></tr>');",
    "    }",
    "  });",
    "  container.innerHTML = '<table class=\"data-table\"><thead>' + headers + '</thead><tbody>' + rows.join('') + '</tbody></table>';",
    "}"
  ].join('\n');
}

fs.writeFileSync(path.join(__dirname, config.outputHtml), html, 'utf8');
console.log('✅ 看板已生成:', config.outputHtml);
console.log('   ASIN 明细:', data.calibreA.details.length, '条');
console.log('   口径A销售额:', data.calibreA.totalSales.toFixed(2), '利润:', data.calibreA.totalProfit.toFixed(2));
console.log('   口径B销售额:', data.calibreB.totalSales.toFixed(2), '利润:', data.calibreB.totalProfit.toFixed(2));
console.log('   月利润完成度 A:', data.calibreA.monthProfitPct.toFixed(2) + '% B:', data.calibreB.monthPct.toFixed(2) + '%');
