// ============================================================
// 一键运行：Excel → JSON → HTML 看板
// 用法: node run.js
// ============================================================
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

// 读取配置（支持 // 注释）
function loadJsonWithComments(filePath) {
  let text = fs.readFileSync(filePath, 'utf8');
  text = text.replace(/\/\*[\s\S]*?\*\//g, '');
  text = text.replace(/^\s*\/\/.*$/gm, '').replace(/\s+\/\/.*$/gm, '');
  return JSON.parse(text);
}

const configPath = path.join(__dirname, 'config.json');
if (!fs.existsSync(configPath)) {
  console.error('❌ 找不到 config.json，请先创建配置文件');
  process.exit(1);
}

const config = loadJsonWithComments(configPath);
const excelPath = path.join(__dirname, config.excelFile);

console.log('====================================');
console.log('  周报看板生成系统');
console.log('====================================');
console.log('Excel 文件:', config.excelFile);
console.log('周报区间:', config.weekRange);
console.log('月目标:', config.monthTarget, '元');
console.log('汇率:', config.usdCnyRate);
console.log('');

// 检查 Excel 是否存在
if (!fs.existsSync(excelPath)) {
  console.error('❌ Excel 文件不存在:', excelPath);
  process.exit(1);
}

// 步骤1：提取数据
console.log('▶ 步骤 1/2: 提取 Excel 数据 → JSON...');
try {
  execSync('node extract.js', { cwd: __dirname, stdio: 'inherit' });
} catch (e) {
  console.error('❌ 数据提取失败');
  process.exit(1);
}

// 步骤2：生成看板
console.log('\n▶ 步骤 2/2: 生成 HTML 看板...');
try {
  execSync('node gen_dashboard.js', { cwd: __dirname, stdio: 'inherit' });
} catch (e) {
  console.error('❌ 看板生成失败');
  process.exit(1);
}

console.log('\n====================================');
console.log('  ✅ 全部完成！');
console.log('====================================');
console.log('HTML 看板:', config.outputHtml);
console.log('\n预览方式:');
console.log('  1. 直接用浏览器打开上述 HTML 文件');
console.log('  2. 或运行 node server.js 启动本地服务 (http://localhost:8765)');
