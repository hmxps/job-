// 读取 9.11周报（8.31-9.6) - 副本.xlsx 的「工作内容」sheet 全部内容
const xlsx = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '9.11周报（8.31-9.6)  - 副本.xlsx');
const wb = xlsx.readFile(filePath);
console.log('Sheet 列表:', wb.SheetNames);

const sheet = wb.Sheets['工作内容'];
const rows = xlsx.utils.sheet_to_json(sheet, { header: 1, defval: '' });

console.log('\n=== 工作内容 sheet 全部行 ===');
console.log('总行数:', rows.length);

rows.forEach((row, idx) => {
  console.log(`\n--- Row ${idx} ---`);
  row.forEach((cell, ci) => {
    if (cell !== '') {
      console.log(`[Col ${ci}]: ${JSON.stringify(cell)}`);
    }
  });
});
