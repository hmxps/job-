// 检查 9.18周报 口径B sheet 是否有内嵌图片
const AdmZip = require('adm-zip');
const path = require('path');

const filePath = path.join(__dirname, '9.18周报（9.7-9.13)  .xlsx');
const zip = new AdmZip(filePath);
const entries = zip.getEntries();

console.log('=== 内嵌图片 ===');
const images = entries.filter(e => e.entryName.match(/\.(png|jpg|jpeg)$/i));
images.forEach(img => {
  console.log(img.entryName, img.header.size, 'bytes');
});
console.log('图片总数:', images.length);

// 提取图片到 extracted_images_918 目录
const fs = require('fs');
const outDir = path.join(__dirname, 'extracted_images_918');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir);
images.forEach((img, i) => {
  const ext = img.entryName.match(/\.(png|jpg|jpeg)$/i)[1];
  const outPath = path.join(outDir, `image_${i+1}.${ext}`);
  fs.writeFileSync(outPath, img.getData());
  console.log('已提取:', outPath);
});
