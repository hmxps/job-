// 读取 9.18周报 各 sheet 详细数据
const xlsx = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '9.18周报（9.7-9.13)  .xlsx');
const wb = xlsx.readFile(filePath);

// 1. 工作内容
console.log('===== 工作内容 =====');
const wc = wb.Sheets['工作内容'];
const wcRows = xlsx.utils.sheet_to_json(wc, { header: 1, defval: '' });
wcRows.forEach((row, idx) => {
  console.log(`Row ${idx}:`, JSON.stringify(row.slice(0,4)));
});

// 2. 口径A 数据
console.log('\n===== 口径A 前5行 =====');
const a = wb.Sheets['本周业绩（商品销售额乘以商品毛利率）'];
const aRows = xlsx.utils.sheet_to_json(a, { header: 1, defval: '' });
for (let i = 0; i < 6; i++) {
  console.log(`Row ${i}:`, JSON.stringify(aRows[i].slice(0, 12)));
}
console.log('总行数:', aRows.length);

// 3. 口径B 数据
console.log('\n===== 口径B 前15行 =====');
const b = wb.Sheets['本周业绩（总销售额乘以总毛利率）'];
const bRows = xlsx.utils.sheet_to_json(b, { header: 1, defval: '' });
for (let i = 0; i < 15; i++) {
  console.log(`Row ${i}:`, JSON.stringify(bRows[i]));
}
