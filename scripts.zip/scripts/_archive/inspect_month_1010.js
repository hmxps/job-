// 检查月度辅助数据列
const xlsx = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '..', '10.10周报（9.28-10.4）.xlsx');
const wb = xlsx.readFile(filePath);
const a = wb.Sheets['本周业绩（商品销售额乘以商品毛利率）'];
const aRows = xlsx.utils.sheet_to_json(a, { header: 1, defval: '' });

console.log('=== 月度辅助数据列(col14-16) ===');
const seen = new Set();
for (let r = 1; r < aRows.length; r++) {
  const time = aRows[r][14];
  const sales = aRows[r][15];
  const profit = aRows[r][16];
  if (time && time !== '' && !seen.has(time)) {
    seen.add(time);
    console.log(`row${r}: 时间=${time}, 销售额=${sales}, 利润=${profit}`);
  }
}

// 口径B daily data
console.log('\n=== 口径B 每日数据 ===');
const b = wb.Sheets['本周业绩（总销售额乘以总毛利率）'];
const bRows = xlsx.utils.sheet_to_json(b, { header: 1, defval: '' });

function excelDateToStr(serial) {
  const date = new Date((serial - 25569) * 86400 * 1000);
  return (date.getMonth() + 1) + '.' + date.getDate();
}

for (let r = 2; r < 9; r++) {
  console.log(`row${r}: date=${bRows[r][0]} -> ${excelDateToStr(bRows[r][0])}, sales=${bRows[r][1]}, profit=${bRows[r][2]}, completion=${bRows[r][3]}`);
}
