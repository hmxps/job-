// 检查 10.10周报 Excel 结构
const xlsx = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '..', '10.10周报（9.28-10.4）.xlsx');
const wb = xlsx.readFile(filePath);
console.log('Sheet names:', wb.SheetNames);

// 检查口径A sheet
const a = wb.Sheets[wb.SheetNames.find(n => n.includes('商品销售额'))];
if (a) {
  const aRows = xlsx.utils.sheet_to_json(a, { header: 1, defval: '' });
  console.log('\n=== 口径A sheet ===');
  console.log('行数:', aRows.length);
  console.log('表头(row0):', JSON.stringify(aRows[0]));
  console.log('示例(row1):', JSON.stringify(aRows[1]));
  console.log('示例(row2):', JSON.stringify(aRows[2]));
  // 检查是否有更多列（月度辅助数据）
  if (aRows[1]) {
    console.log('row1 列数:', aRows[1].length);
    for (let c = 0; c < aRows[1].length; c++) {
      console.log(`  col[${c}]: ${aRows[1][c]}`);
    }
  }
}

// 检查口径B sheet
const b = wb.Sheets[wb.SheetNames.find(n => n.includes('总销售额'))];
if (b) {
  const bRows = xlsx.utils.sheet_to_json(b, { header: 1, defval: '' });
  console.log('\n=== 口径B sheet ===');
  console.log('行数:', bRows.length);
  console.log('表头(row0):', JSON.stringify(bRows[0]));
  for (let r = 0; r < Math.min(15, bRows.length); r++) {
    console.log(`row${r}:`, JSON.stringify(bRows[r]));
  }
}

// 检查工作内容 sheet
const wc = wb.Sheets[wb.SheetNames.find(n => n.includes('工作内容'))];
if (wc) {
  const wcRows = xlsx.utils.sheet_to_json(wc, { header: 1, defval: '' });
  console.log('\n=== 工作内容 sheet ===');
  console.log('行数:', wcRows.length);
  for (let r = 0; r < Math.min(12, wcRows.length); r++) {
    console.log(`row${r}:`, JSON.stringify(wcRows[r]));
  }
}
