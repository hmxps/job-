// 提取 9.18周报 口径A 数据并生成 dashboard_data_918.json
const xlsx = require('xlsx');
const path = require('path');
const fs = require('fs');

const filePath = path.join(__dirname, '..', '9.18周报（9.7-9.13)  .xlsx');
const wb = xlsx.readFile(filePath);

// ============ 口径A ============
const a = wb.Sheets['本周业绩（商品销售额乘以商品毛利率）'];
const aRows = xlsx.utils.sheet_to_json(a, { header: 1, defval: '' });

const details = [];
let totalSalesA = 0, totalProfitA = 0;
const catMap = {};
const personMap = {};

for (let i = 1; i < aRows.length; i++) {
  const row = aRows[i];
  if (!row[3] || row[3] === '') continue; // 父ASIN 为空跳过
  const person = row[1] || '';
  const category = row[2] || '';
  const asin = row[3];
  const sales = Number(row[4]) || 0;
  const profit = Number(row[5]) || 0;
  // 4km毛利率 是百分比如 "24.16%"
  const margin4kmStr = String(row[6] || '').replace('%', '');
  const margin4km = margin4kmStr ? Number(margin4kmStr) / 100 : null;
  // 船长毛利率 是小数
  const marginCaptain = row[7] !== '' && row[7] !== null ? Number(row[7]) : null;

  details.push({ person, category, asin, sales, profit, margin4km, marginCaptain });
  totalSalesA += sales;
  totalProfitA += profit;

  if (!catMap[category]) catMap[category] = { name: category, sales: 0, profit: 0 };
  catMap[category].sales += sales;
  catMap[category].profit += profit;

  if (!personMap[person]) personMap[person] = { name: person, sales: 0, profit: 0 };
  personMap[person].sales += sales;
  personMap[person].profit += profit;
}

const categories = Object.values(catMap).sort((a, b) => b.sales - a.sales);
const personnel = Object.values(personMap).sort((a, b) => b.sales - a.sales);

console.log('口径A ASIN 数:', details.length);
console.log('口径A 总销售额:', totalSalesA.toFixed(2));
console.log('口径A 总利润:', totalProfitA.toFixed(2));
console.log('口径A 品类数:', categories.length);
console.log('口径A 人员:', personnel.map(p => p.name).join(', '));
console.log('品类 Top5:', categories.slice(0, 5).map(c => c.name + ':' + c.sales.toFixed(0)).join(', '));

// ============ 口径B ============
const b = wb.Sheets['本周业绩（总销售额乘以总毛利率）'];
const bRows = xlsx.utils.sheet_to_json(b, { header: 1, defval: '' });

function excelDateToStr(serial) {
  // Excel 日期序列号转 MM.DD
  const date = new Date((serial - 25569) * 86400 * 1000);
  const m = date.getMonth() + 1;
  const d = date.getDate();
  return m + '.' + d;
}

function extractDaily(startRow) {
  const data = [];
  for (let i = startRow; i < startRow + 7 && i < bRows.length; i++) {
    const row = bRows[i];
    if (row[0] === '' || row[0] === null) break;
    data.push({
      date: excelDateToStr(row[0]),
      sales: Number(row[1]) || 0,
      profit: Number(row[2]) || 0,
      completion: Number(row[3]) || 0
    });
  }
  return data;
}

const groupDaily = extractDaily(2);
const gaojieDaily = extractDaily(12);
const zhengchunyanDaily = extractDaily(22);
const zhangzhipengDaily = extractDaily(32);
const liyanDaily = extractDaily(42);

let totalSalesB = 0, totalProfitB = 0;
groupDaily.forEach(d => { totalSalesB += d.sales; totalProfitB += d.profit; });
console.log('\n口径B 本周总销售额:', totalSalesB.toFixed(2));
console.log('口径B 本周总利润:', totalProfitB.toFixed(2));
console.log('口径B 日均销售额:', (totalSalesB / 7).toFixed(2));
console.log('口径B 完成情况:', groupDaily.map(d => d.date + ':' + (d.completion * 100).toFixed(0) + '%').join(', '));

// 上周数据（8.31-9.6）用于环比
const lastWeekSalesA = 889013.94;
const lastWeekProfitA = 115704.34;
const lastWeekSalesB = 136155.44;
const lastWeekProfitB = 18705.27;

// 口径A 本月累计利润 = 9.1-9.5 利润 + 8.31-9.6 利润（来自 Excel 月度辅助数据）
const monthCumProfitA = 95791.65572 + 91464.28147;

// 口径A 月利润目标完成度（月利润目标 500000 RMB）
const monthTargetProfitA = 500000;
const monthPctProfitA = monthCumProfitA / monthTargetProfitA * 100;
console.log('口径A 本月累计利润:', monthCumProfitA.toFixed(2));
console.log('口径A 月利润目标完成度:', monthPctProfitA.toFixed(2) + '%');

// 口径B 月利润目标完成度（目标 500000 人民币，利润数据为美元需换算）
const USD_CNY = 6.7487; // 2026-09-21 美元兑人民币中间价
const lastWeekSepProfitB = 10540.79433; // 上周（8.31-9.6）中属于9月的利润
const monthCumProfitB = lastWeekSepProfitB + totalProfitB; // 本月累计利润（USD）
const monthCumProfitBCNY = monthCumProfitB * USD_CNY; // 本月累计利润换算为人民币
const monthTargetB = 500000; // 月利润目标 500000 人民币
const monthPctB = monthCumProfitBCNY / monthTargetB * 100;
console.log('口径B 上周9月利润(USD):', lastWeekSepProfitB.toFixed(2));
console.log('口径B 本周利润(USD):', totalProfitB.toFixed(2));
console.log('口径B 本月累计利润(USD):', monthCumProfitB.toFixed(2));
console.log('口径B 本月累计利润(CNY):', monthCumProfitBCNY.toFixed(2), '(汇率', USD_CNY, ')');
console.log('口径B 月利润目标完成度:', monthPctB.toFixed(2) + '%');

// 环比
const salesWoWA = (totalSalesA - lastWeekSalesA) / lastWeekSalesA * 100;
const profitWoWA = (totalProfitA - lastWeekProfitA) / lastWeekProfitA * 100;
const salesWoWB = (totalSalesB - lastWeekSalesB) / lastWeekSalesB * 100;
const profitWoWB = (totalProfitB - lastWeekProfitB) / lastWeekProfitB * 100;
console.log('口径A 销售额环比:', salesWoWA.toFixed(2) + '%');
console.log('口径A 利润环比:', profitWoWA.toFixed(2) + '%');
console.log('口径B 销售额环比:', salesWoWB.toFixed(2) + '%');
console.log('口径B 利润环比:', profitWoWB.toFixed(2) + '%');

// 输出 JSON
const output = {
  week: '9.7-9.13',
  lastWeek: '8.31-9.6',
  calibreA: {
    details,
    categories,
    personnel,
    totalSales: totalSalesA,
    totalProfit: totalProfitA,
    lastWeekSales: lastWeekSalesA,
    lastWeekProfit: lastWeekProfitA,
    monthCumProfit: monthCumProfitA,
    monthProfitTarget: monthTargetProfitA,
    monthProfitPct: monthPctProfitA,
    salesWoW: salesWoWA,
    profitWoW: profitWoWA
  },
  calibreB: {
    groupDaily,
    gaojieDaily,
    zhengchunyanDaily,
    zhangzhipengDaily,
    liyanDaily,
    totalSales: totalSalesB,
    totalProfit: totalProfitB,
    lastWeekSepProfit: lastWeekSepProfitB,
    monthCumProfit: monthCumProfitB,
    monthCumProfitCNY: monthCumProfitBCNY,
    lastWeekSales: lastWeekSalesB,
    lastWeekProfit: lastWeekProfitB,
    monthTarget: monthTargetB,
    monthPct: monthPctB,
    usdCnyRate: USD_CNY,
    salesWoW: salesWoWB,
    profitWoW: profitWoWB
  }
};

fs.writeFileSync(path.join(__dirname, 'dashboard_data_918.json'), JSON.stringify(output, null, 2), 'utf8');
console.log('\n已保存: dashboard_data_918.json');
