// 读取 9.18周报（9.7-9.13)  .xlsx 的 sheet 结构
const xlsx = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '9.18周报（9.7-9.13)  .xlsx');
const wb = xlsx.readFile(filePath);
console.log('Sheet 列表:', wb.SheetNames);

wb.SheetNames.forEach(name => {
  const sheet = wb.Sheets[name];
  const rows = xlsx.utils.sheet_to_json(sheet, { header: 1, defval: '' });
  console.log(`\n=== ${name} ===`);
  console.log('行数:', rows.length);
  if (rows.length > 0) {
    console.log('表头 Row 0:', JSON.stringify(rows[0]));
  }
});
