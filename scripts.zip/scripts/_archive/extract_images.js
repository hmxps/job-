const AdmZip = require('adm-zip');
const fs = require('fs');
const path = 'd:/周报/9.11周报（8.31-9.6) .xlsx';
const zip = new AdmZip(path);
const outDir = 'd:/周报/extracted_images';
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

// Read drawing rels to map images to sheets
const draw1rels = zip.getEntry('xl/drawings/_rels/drawing1.xml.rels');
const draw2rels = zip.getEntry('xl/drawings/_rels/drawing2.xml.rels');
const draw1 = zip.getEntry('xl/drawings/drawing1.xml');
const draw2 = zip.getEntry('xl/drawings/drawing2.xml');
const sheet5rels = zip.getEntry('xl/worksheets/_rels/sheet5.xml.rels');

console.log('=== drawing1.xml.rels (sheet1=可视化) ===');
console.log(draw1rels ? draw1rels.getData().toString('utf8') : 'not found');
console.log('\n=== drawing2.xml.rels (sheet5=本周业绩总) ===');
console.log(draw2rels ? draw2rels.getData().toString('utf8') : 'not found');
console.log('\n=== sheet5.xml.rels ===');
console.log(sheet5rels ? sheet5rels.getData().toString('utf8') : 'not found');
console.log('\n=== drawing2.xml (positions) ===');
console.log(draw2 ? draw2.getData().toString('utf8') : 'not found');

// Extract all images
['image1.png','image2.png','image3.png','image4.png','image5.png'].forEach(name => {
  const entry = zip.getEntry('xl/media/' + name);
  if (entry) {
    const buf = entry.getData();
    fs.writeFileSync(outDir + '/' + name, buf);
    console.log('Extracted:', name, buf.length, 'bytes');
  }
});
