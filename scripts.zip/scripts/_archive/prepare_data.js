const XLSX = require('xlsx');
const fs = require('fs');

const wb = XLSX.readFile('d:/周报/9.11周报（8.31-9.6) .xlsx');
const data = { calibreA: {}, calibreB: {} };

// ============ 口径A：可视化sheet汇总数据 ============
const viz = XLSX.utils.sheet_to_json(wb.Sheets['可视化'], { header: 1, defval: '' });

// 周销售趋势(6周)
data.calibreA.weeklyTrend = [];
for (let i = 4; i <= 9; i++) {
  const row = viz[i];
  if (row[3]) {
    data.calibreA.weeklyTrend.push({
      week: row[3],
      sales: Number(row[4]) || 0,
      profit: Number(row[5]) || 0
    });
  }
}
// 补充利润(部分周在AC列)
data.calibreA.weeklyTrend[5].profit = 115704.3409;

// 平均毛利率、环比
data.calibreA.avgMargin = viz[2][18]; // 13.01%
data.calibreA.salesMoM = viz[3][19]; // 3.95%
data.calibreA.profitMoM = viz[4][19]; // -1.09%

// 负责人业绩(4人)
data.calibreA.personnel = [];
for (let i = 25; i <= 28; i++) {
  const row = viz[i];
  if (row[2]) {
    data.calibreA.personnel.push({
      name: row[2],
      sales: Number(row[3]) || 0,
      profit: Number(row[4]) || 0
    });
  }
}

// 产品种类(15类) - 从透视表
const pivot = XLSX.utils.sheet_to_json(wb.Sheets['数据透视表（辅助作用）'], { header: 1, defval: '' });
data.calibreA.categories = [];
for (let i = 1; i < pivot.length - 1; i++) {
  const row = pivot[i];
  if (row[0] && row[0] !== '总计') {
    data.calibreA.categories.push({
      name: row[0],
      sales: Number(row[1]) || 0,
      profit: Number(row[2]) || 0
    });
  }
}

// 月目标完成情况
data.calibreA.monthTarget = { completed: '18.29%', uncompleted: '81.71%' };

// ============ 口径A：明细180条 ============
const detail = XLSX.utils.sheet_to_json(wb.Sheets['本周业绩（商品销售额乘以商品毛利率）'], { header: 1, defval: '' });
data.calibreA.details = [];
for (let i = 1; i < detail.length; i++) {
  const row = detail[i];
  if (row[0] && row[2] && row[3]) {
    const parseMargin = (v) => {
      if (!v) return 0;
      const s = String(v);
      if (s.includes('%')) return parseFloat(s) / 100;
      return Number(v) || 0;
    };
    data.calibreA.details.push({
      date: row[0],
      person: row[1],
      category: row[2],
      asin: row[3],
      sales: Number(row[4]) || 0,
      profit: Number(row[5]) || 0,
      margin4km: parseMargin(row[6]),
      marginCaptain: parseMargin(row[7])
    });
  }
}

// ============ 口径B：每日数据(从图片提取) ============
data.calibreB.groupDaily = [
  { date: '8.31', sales: 20308.75, profit: 2793.327522, completion: 1.1250 },
  { date: '9.1', sales: 23393.52, profit: 3210.836119, completion: 1.2932 },
  { date: '9.2', sales: 21997.59, profit: 3032.53329, completion: 1.2213 },
  { date: '9.3', sales: 22369.37, profit: 3100.702123, completion: 1.2488 },
  { date: '9.4', sales: 20195.69, profit: 2747.944554, completion: 1.1067 },
  { date: '9.5', sales: 13933.81, profit: 1890.634302, completion: 0.7614 },
  { date: '9.6', sales: 13956.71, profit: 1929.294338, completion: 0.7770 }
];
data.calibreB.gaojieDaily = [
  { date: '8.31', sales: 9239.11, profit: 1042.171608, completion: 0.8395 },
  { date: '9.1', sales: 11370.06, profit: 1282.542768, completion: 1.0331 },
  { date: '9.2', sales: 12362.89, profit: 1394.533992, completion: 1.1233 },
  { date: '9.3', sales: 11229.86, profit: 1266.728208, completion: 1.0203 },
  { date: '9.4', sales: 11585.82, profit: 1306.880496, completion: 1.0527 },
  { date: '9.5', sales: 7432.59, profit: 838.396152, completion: 0.6753 },
  { date: '9.6', sales: 7329.85, profit: 826.80708, completion: 0.6660 }
];
data.calibreB.zhengchunyanDaily = [
  { date: '8.31', sales: 9068.42, profit: 1141.714078, completion: 1.1496 },
  { date: '9.1', sales: 9713.41, profit: 1222.918319, completion: 1.2313 },
  { date: '9.2', sales: 7257.82, profit: 913.759538, completion: 0.9200 },
  { date: '9.3', sales: 8743.85, profit: 1100.850715, completion: 1.1084 },
  { date: '9.4', sales: 6649.10, profit: 837.121690, completion: 0.8429 },
  { date: '9.5', sales: 5222.78, profit: 657.548002, completion: 0.6621 },
  { date: '9.6', sales: 5132.46, profit: 646.176714, completion: 0.6506 }
];
data.calibreB.zhangzhipengDaily = [
  { date: '8.31', sales: 1946.63, profit: 587.103610, completion: 2.3645 },
  { date: '9.1', sales: 2229.53, profit: 672.426250, completion: 2.7082 },
  { date: '9.2', sales: 2308.36, profit: 696.201380, completion: 2.8039 },
  { date: '9.3', sales: 2297.22, profit: 692.841550, completion: 2.7904 },
  { date: '9.4', sales: 1843.91, profit: 556.123260, completion: 2.2398 },
  { date: '9.5', sales: 1193.75, profit: 360.035000, completion: 1.4500 },
  { date: '9.6', sales: 1442.36, profit: 435.015780, completion: 1.7520 }
];
data.calibreB.liyanDaily = [
  { date: '8.31', sales: 54.59, profit: 22.338228, completion: null },
  { date: '9.1', sales: 80.52, profit: 32.948784, completion: 0.6635 },
  { date: '9.2', sales: 68.52, profit: 28.038384, completion: 0.5646 },
  { date: '9.3', sales: 98.44, profit: 40.281648, completion: 0.8112 },
  { date: '9.4', sales: 116.86, profit: 47.819112, completion: 0.9629 },
  { date: '9.5', sales: 84.69, profit: 34.655148, completion: 0.6979 },
  { date: '9.6', sales: 52.04, profit: 21.294768, completion: 0.4288 }
];
data.calibreB.monthTarget = { target: 500000, completed: 0.1829 };

fs.writeFileSync('d:/周报/dashboard_data.json', JSON.stringify(data, null, 2), 'utf-8');
console.log('Data saved. calibreA details:', data.calibreA.details.length, 'rows');
console.log('calibreA categories:', data.calibreA.categories.length);
console.log('calibreA personnel:', data.calibreA.personnel.length);
console.log('calibreB days:', data.calibreB.groupDaily.length);
