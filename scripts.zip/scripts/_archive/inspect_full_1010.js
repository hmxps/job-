// 完整检查口径B 和工作内容
const xlsx = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '..', '10.10周报（9.28-10.4）.xlsx');
const wb = xlsx.readFile(filePath);

// 口径B - 检查所有人员数据
const b = wb.Sheets['本周业绩（总销售额乘以总毛利率）'];
const bRows = xlsx.utils.sheet_to_json(b, { header: 1, defval: '' });

function excelDateToStr(serial) {
  const date = new Date((serial - 25569) * 86400 * 1000);
  return (date.getMonth() + 1) + '.' + date.getDate();
}

console.log('=== 口径B 全部数据 ===');
for (let r = 0; r < bRows.length; r++) {
  const row = bRows[r];
  if (row[0] && row[0] !== '') {
    if (typeof row[0] === 'string' && row[0].includes('完成情况')) {
      console.log(`\nrow${r}: [${row[0]}]`);
    } else if (row[0] === '时间') {
      console.log(`row${r}: 表头=${JSON.stringify(row)}`);
    } else if (typeof row[0] === 'number') {
      console.log(`row${r}: date=${excelDateToStr(row[0])}, sales=${row[1]}, profit=${row[2]}, completion=${row[3]}`);
    } else {
      console.log(`row${r}: ${row[0]}`);
    }
  }
}

// 口径A - 确认人员列表
const a = wb.Sheets['本周业绩（商品销售额乘以商品毛利率）'];
const aRows = xlsx.utils.sheet_to_json(a, { header: 1, defval: '' });
const persons = new Set();
for (let i = 1; i < aRows.length; i++) {
  if (aRows[i][1]) persons.add(aRows[i][1]);
}
console.log('\n=== 口径A 人员:', [...persons].join(', '));

// 工作内容
const wc = wb.Sheets['工作内容'];
const wcRows = xlsx.utils.sheet_to_json(wc, { header: 1, defval: '' });
console.log('\n=== 工作内容完整数据 ===');
for (let r = 0; r < wcRows.length; r++) {
  console.log(`\n--- row${r} ---`);
  for (let c = 0; c < wcRows[r].length; c++) {
    if (wcRows[r][c] && wcRows[r][c] !== '') {
      console.log(`  [col${c}] ${wcRows[r][c]}`);
    }
  }
}
