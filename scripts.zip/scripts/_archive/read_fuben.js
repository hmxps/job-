const XLSX = require('xlsx');
const wb = XLSX.readFile('d:/周报/9.11周报（8.31-9.6)  - 副本.xlsx');
console.log('Sheet names:', wb.SheetNames);
console.log('\n==== 各 sheet 前 30 行预览 ====');
wb.SheetNames.forEach(name=>{
  const ws = wb.Sheets[name];
  const rows = XLSX.utils.sheet_to_json(ws, {header:1, defval:''});
  console.log('\n--- Sheet: '+name+' (共 '+(rows.length)+' 行) ---');
  for(let i=0; i<Math.min(30, rows.length); i++){
    const r = rows[i].filter(c=>c!=='');
    if(r.length>0) console.log(i+': '+JSON.stringify(r).slice(0,200));
  }
});
