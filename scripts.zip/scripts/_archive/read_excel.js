const XLSX = require('xlsx');
const path = 'd:/周报/9.11周报（8.31-9.6) .xlsx';
const wb = XLSX.readFile(path);
console.log('Sheets:', wb.SheetNames);
for (const name of wb.SheetNames) {
  const ws = wb.Sheets[name];
  const data = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '', raw: false });
  console.log('\n========== Sheet:', name, '==========');
  console.log('Rows:', data.length);
  // Print all rows
  for (let i = 0; i < data.length; i++) {
    console.log(`Row ${i+1}:`, JSON.stringify(data[i]));
  }
}
