const XLSX = require('xlsx');
const fs = require('fs');
const path = 'd:/周报/9.11周报（8.31-9.6) .xlsx';
// xlsx is a zip; check for embedded media
const AdmZip = (() => { try { return require('adm-zip'); } catch(e) { return null; } })();
if (AdmZip) {
  const zip = new AdmZip(path);
  const entries = zip.getEntries();
  console.log('Zip entries:');
  entries.forEach(e => console.log(' ', e.entryName, e.header.size, 'bytes'));
} else {
  console.log('adm-zip not installed, trying manual zip listing');
}
