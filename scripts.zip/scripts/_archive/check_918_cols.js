// 读取 9.18周报 口径A 完整列结构
const xlsx = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '9.18周报（9.7-9.13)  .xlsx');
const wb = xlsx.readFile(filePath);
const a = wb.Sheets['本周业绩（商品销售额乘以商品毛利率）'];
const aRows = xlsx.utils.sheet_to_json(a, { header: 1, defval: '' });

console.log('表头全部列:', JSON.stringify(aRows[0]));
console.log('\n前6行全部列:');
for (let i = 1; i < 7; i++) {
  console.log(`Row ${i}:`, JSON.stringify(aRows[i]));
}

// 检查是否有"上周"相关列
console.log('\n检查列9-16的内容:');
for (let i = 1; i < 4; i++) {
  console.log(`Row ${i} cols 8-16:`, JSON.stringify(aRows[i].slice(8, 17)));
}
