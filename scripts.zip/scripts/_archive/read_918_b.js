// 提取 9.18周报 口径B 全部人员每日数据
const xlsx = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '9.18周报（9.7-9.13)  .xlsx');
const wb = xlsx.readFile(filePath);
const b = wb.Sheets['本周业绩（总销售额乘以总毛利率）'];
const rows = xlsx.utils.sheet_to_json(b, { header: 1, defval: '' });

console.log('===== 口径B 全部行 =====');
rows.forEach((row, idx) => {
  if (row.some(c => c !== '')) {
    console.log(`Row ${idx}:`, JSON.stringify(row));
  }
});
