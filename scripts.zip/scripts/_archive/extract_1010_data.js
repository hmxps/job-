// 提取 10.10周报 口径A/B 数据并生成 dashboard_data_1010.json
const xlsx = require('xlsx');
const path = require('path');
const fs = require('fs');

const filePath = path.join(__dirname, '..', '10.10周报（9.28-10.4）.xlsx');
const wb = xlsx.readFile(filePath);

// ============ 口径A ============
const a = wb.Sheets['本周业绩（商品销售额乘以商品毛利率）'];
const aRows = xlsx.utils.sheet_to_json(a, { header: 1, defval: '' });

const details = [];
let totalSalesA = 0, totalProfitA = 0;
const catMap = {};
const personMap = {};

for (let i = 1; i < aRows.length; i++) {
  const row = aRows[i];
  if (!row[3] || row[3] === '') continue;
  const person = row[1] || '';
  const category = row[2] || '';
  const asin = row[3];
  const sales = Number(row[4]) || 0;
  const profit = Number(row[5]) || 0;
  const margin4kmStr = String(row[6] || '').replace('%', '');
  const margin4km = margin4kmStr ? Number(margin4kmStr) / 100 : null;
  const marginCaptain = row[7] !== '' && row[7] !== null ? Number(row[7]) : null;

  details.push({ person, category, asin, sales, profit, margin4km, marginCaptain });
  totalSalesA += sales;
  totalProfitA += profit;

  if (!catMap[category]) catMap[category] = { name: category, sales: 0, profit: 0 };
  catMap[category].sales += sales;
  catMap[category].profit += profit;

  if (!personMap[person]) personMap[person] = { name: person, sales: 0, profit: 0 };
  personMap[person].sales += sales;
  personMap[person].profit += profit;
}

const categories = Object.values(catMap).sort((a, b) => b.sales - a.sales);
const personnel = Object.values(personMap).sort((a, b) => b.sales - a.sales);

console.log('口径A ASIN 数:', details.length);
console.log('口径A 总销售额:', totalSalesA.toFixed(2));
console.log('口径A 总利润:', totalProfitA.toFixed(2));
console.log('口径A 品类数:', categories.length);
console.log('口径A 人员:', personnel.map(p => p.name).join(', '));
console.log('品类 Top5:', categories.slice(0, 5).map(c => c.name + ':' + c.sales.toFixed(0)).join(', '));

// ============ 口径B ============
const b = wb.Sheets['本周业绩（总销售额乘以总毛利率）'];
const bRows = xlsx.utils.sheet_to_json(b, { header: 1, defval: '' });

function excelDateToStr(serial) {
  const date = new Date((serial - 25569) * 86400 * 1000);
  const m = date.getMonth() + 1;
  const d = date.getDate();
  return m + '.' + d;
}

function extractDaily(startRow) {
  const data = [];
  for (let i = startRow; i < startRow + 7 && i < bRows.length; i++) {
    const row = bRows[i];
    if (row[0] === '' || row[0] === null) break;
    data.push({
      date: excelDateToStr(row[0]),
      sales: Number(row[1]) || 0,
      profit: Number(row[2]) || 0,
      completion: Number(row[3]) || 0
    });
  }
  return data;
}

const groupDaily = extractDaily(2);
const gaojieDaily = extractDaily(12);
const zhengchunyanDaily = extractDaily(22);
const zhangzhipengDaily = extractDaily(32);
const liyanDaily = extractDaily(42);

let totalSalesB = 0, totalProfitB = 0;
groupDaily.forEach(d => { totalSalesB += d.sales; totalProfitB += d.profit; });
console.log('\n口径B 本周总销售额:', totalSalesB.toFixed(2));
console.log('口径B 本周总利润:', totalProfitB.toFixed(2));
console.log('口径B 日均销售额:', (totalSalesB / 7).toFixed(2));
console.log('口径B 完成情况:', groupDaily.map(d => d.date + ':' + (d.completion * 100).toFixed(0) + '%').join(', '));

// ============ 环比数据（上周 9.21-9.27）============
const lastWeekSalesA = 760601.86;
const lastWeekProfitA = 77218.966853;
const lastWeekSalesB = 113925.77;
const lastWeekProfitB = 9957.103812;

// ============ 9月全月累计利润（5段：9.1-9.30）============
// 口径A（RMB）- 第5段为本周9月部分(9.28-9.30)，从Excel月度辅助数据获取
const sepWeek1ProfitA = 91464.28147;   // 9.1-9.6 9月部分
const sepWeek2ProfitA = 95791.655724;   // 9.7-9.13
const sepWeek3ProfitA = 74896.599907;   // 9.14-9.20
const sepWeek4ProfitA = 77218.966853;   // 9.21-9.27
// 从Excel月度辅助数据获取9.28-9.30利润
const sepWeek5ProfitA = 45509.48678041; // 9.28-9.30（本周9月部分）
const monthCumProfitA = sepWeek1ProfitA + sepWeek2ProfitA + sepWeek3ProfitA + sepWeek4ProfitA + sepWeek5ProfitA;

// 口径B（USD）- 第5段为本周9月部分(9.28-9.30)，从日数据累加
const sepWeek1ProfitB = 10540.79433;     // 9.1-9.6 9月部分
const sepWeek2ProfitB = 13072.784681;    // 9.7-9.13
const sepWeek3ProfitB = 10717.321778;    // 9.14-9.20
const sepWeek4ProfitB = 9957.103812;     // 9.21-9.27
// 本周9月部分(9.28-9.30)利润 = 前3天利润之和
const sepWeek5ProfitB = groupDaily.slice(0, 3).reduce((s, d) => s + d.profit, 0);
const monthCumProfitB = sepWeek1ProfitB + sepWeek2ProfitB + sepWeek3ProfitB + sepWeek4ProfitB + sepWeek5ProfitB;

const USD_CNY = 6.7330; // 2026-10-09 美元兑人民币中间价（国庆假期后首个交易日）
const monthCumProfitBCNY = monthCumProfitB * USD_CNY;
const monthTarget = 500000;

const monthPctA = monthCumProfitA / monthTarget * 100;
const monthPctB = monthCumProfitBCNY / monthTarget * 100;

console.log('\n=== 9月利润目标完成度（9月全月）===');
console.log('口径A 9月累计利润:', monthCumProfitA.toFixed(2),
  '(9.1-9.6:', sepWeek1ProfitA.toFixed(2),
  '+ 9.7-9.13:', sepWeek2ProfitA.toFixed(2),
  '+ 9.14-9.20:', sepWeek3ProfitA.toFixed(2),
  '+ 9.21-9.27:', sepWeek4ProfitA.toFixed(2),
  '+ 9.28-9.30:', sepWeek5ProfitA.toFixed(2), ')');
console.log('口径A 9月利润目标完成度:', monthPctA.toFixed(2) + '%');
console.log('口径B 9月累计利润(USD):', monthCumProfitB.toFixed(2),
  '(9.1-9.6:', sepWeek1ProfitB.toFixed(2),
  '+ 9.7-9.13:', sepWeek2ProfitB.toFixed(2),
  '+ 9.14-9.20:', sepWeek3ProfitB.toFixed(2),
  '+ 9.21-9.27:', sepWeek4ProfitB.toFixed(2),
  '+ 9.28-9.30:', sepWeek5ProfitB.toFixed(2), ')');
console.log('口径B 9月累计利润(CNY):', monthCumProfitBCNY.toFixed(2), '(汇率', USD_CNY, ')');
console.log('口径B 9月利润目标完成度:', monthPctB.toFixed(2) + '%');

// 环比
const salesWoWA = (totalSalesA - lastWeekSalesA) / lastWeekSalesA * 100;
const profitWoWA = (totalProfitA - lastWeekProfitA) / lastWeekProfitA * 100;
const salesWoWB = (totalSalesB - lastWeekSalesB) / lastWeekSalesB * 100;
const profitWoWB = (totalProfitB - lastWeekProfitB) / lastWeekProfitB * 100;
console.log('\n=== 环比 ===');
console.log('口径A 销售额环比:', salesWoWA.toFixed(2) + '%');
console.log('口径A 利润环比:', profitWoWA.toFixed(2) + '%');
console.log('口径B 销售额环比:', salesWoWB.toFixed(2) + '%');
console.log('口径B 利润环比:', profitWoWB.toFixed(2) + '%');

// 输出 JSON
const output = {
  week: '9.28-10.4',
  lastWeek: '9.21-9.27',
  calibreA: {
    details,
    categories,
    personnel,
    totalSales: totalSalesA,
    totalProfit: totalProfitA,
    lastWeekSales: lastWeekSalesA,
    lastWeekProfit: lastWeekProfitA,
    monthCumProfit: monthCumProfitA,
    monthProfitTarget: monthTarget,
    monthProfitPct: monthPctA,
    salesWoW: salesWoWA,
    profitWoW: profitWoWA
  },
  calibreB: {
    groupDaily,
    gaojieDaily,
    zhengchunyanDaily,
    zhangzhipengDaily,
    liyanDaily,
    totalSales: totalSalesB,
    totalProfit: totalProfitB,
    lastWeekSepProfit: sepWeek1ProfitB,
    prevWeekProfit: sepWeek2ProfitB,
    week3Profit: sepWeek3ProfitB,
    week4Profit: sepWeek4ProfitB,
    sepWeek5Profit: sepWeek5ProfitB,
    monthCumProfit: monthCumProfitB,
    monthCumProfitCNY: monthCumProfitBCNY,
    lastWeekSales: lastWeekSalesB,
    lastWeekProfit: lastWeekProfitB,
    monthTarget: monthTarget,
    monthPct: monthPctB,
    usdCnyRate: USD_CNY,
    salesWoW: salesWoWB,
    profitWoW: profitWoWB
  }
};

fs.writeFileSync(path.join(__dirname, 'dashboard_data_1010.json'), JSON.stringify(output, null, 2), 'utf8');
console.log('\n已保存: dashboard_data_1010.json');
