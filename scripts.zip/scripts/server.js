const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8765;
const ROOT = path.join(__dirname, '..');

const mime = {
  '.html':'text/html; charset=utf-8',
  '.js':'application/javascript',
  '.json':'application/json',
  '.png':'image/png'
};

http.createServer((req,res)=>{
  let p = decodeURIComponent(req.url.split('?')[0]);
  if(p==='/') p='/周报看板_9.21-9.27.html';
  const fp = path.join(ROOT, p);
  fs.readFile(fp,(err,data)=>{
    if(err){res.writeHead(404);res.end('Not found: '+p);return;}
    const ext = path.extname(fp).toLowerCase();
    res.writeHead(200,{'Content-Type':mime[ext]||'application/octet-stream'});
    res.end(data);
  });
}).listen(PORT,()=>console.log('Server: http://localhost:'+PORT));
