// ============================================================
// 通用 Excel → JSON 提取脚本
// 读取 config.json 配置 + Excel 文件 → 输出 dashboard_data.json
// 用法: node extract.js
// ============================================================
const xlsx = require('xlsx');
const path = require('path');
const fs = require('fs');

// 读取配置（支持 // 注释，自动去除后再解析）
function loadJsonWithComments(filePath) {
  let text = fs.readFileSync(filePath, 'utf8');
  // 去掉 /* ... */ 块注释
  text = text.replace(/\/\*[\s\S]*?\*\//g, '');
  // 去掉 // 行注释（不匹配字符串内的 //，简化处理：只去行首到行尾的 //）
  text = text.replace(/^\s*\/\/.*$/gm, '').replace(/\s+\/\/.*$/gm, '');
  return JSON.parse(text);
}

const config = loadJsonWithComments(path.join(__dirname, 'config.json'));

const excelPath = path.join(__dirname, config.excelFile);
console.log(`读取 Excel: ${excelPath}`);
const wb = xlsx.readFile(excelPath);

// ============ 口径A：ASIN 明细 ============
const sheetA = wb.Sheets[config.sheets.calibreA];
const aRows = xlsx.utils.sheet_to_json(sheetA, { header: 1, defval: '' });

const details = [];
let totalSalesA = 0, totalProfitA = 0;
const catMap = {};
const personMap = {};

for (let i = 1; i < aRows.length; i++) {
  const row = aRows[i];
  if (!row[3] || row[3] === '') continue;

  const person = row[1] || '';
  const category = row[2] || '';
  const asin = row[3];
  const sales = Number(row[4]) || 0;
  const profit = Number(row[5]) || 0;
  const margin4kmStr = String(row[6] || '').replace('%', '');
  const margin4km = margin4kmStr ? Number(margin4kmStr) / 100 : null;
  const marginCaptain = row[7] !== '' && row[7] !== null ? Number(row[7]) : null;

  details.push({ person, category, asin, sales, profit, margin4km, marginCaptain });
  totalSalesA += sales;
  totalProfitA += profit;

  if (!catMap[category]) catMap[category] = { name: category, sales: 0, profit: 0 };
  catMap[category].sales += sales;
  catMap[category].profit += profit;

  if (!personMap[person]) personMap[person] = { name: person, sales: 0, profit: 0 };
  personMap[person].sales += sales;
  personMap[person].profit += profit;
}

const categories = Object.values(catMap).sort((a, b) => b.sales - a.sales);
const personnel = Object.values(personMap).sort((a, b) => b.sales - a.sales);

// ============ 往期周趋势（口径A sheet 右侧内嵌趋势表，K-M 列） ============
// 结构：第0列开始是 ASIN 明细，第10-12列为「时间 | 销售额 | 利润额」，表头行也在同列
const weeklyTrend = [];
const weekRangeRe = /^\d{1,2}\.\d{1,2}\s*[-~]\s*\d{1,2}\.\d{1,2}$/;
for (let i = 1; i < aRows.length; i++) {
  const row = aRows[i];
  if (row[10] === '' || row[10] === undefined || row[10] === null) break;
  const week = String(row[10]).trim();
  // 跳过表头「时间」等非周区间行，只保留 9.14-9.20 这种格式
  if (!weekRangeRe.test(week)) continue;
  weeklyTrend.push({
    week,
    sales: Number(row[11]) || 0,
    profit: Number(row[12]) || 0
  });
}
// 表里可能已累积超过 5 周，取最后 5 周（含本周）
const weeklyTrendRecent = weeklyTrend.slice(-5);
console.log('往期周趋势:', weeklyTrendRecent.map(t => t.week).join(' → '), '(' + weeklyTrendRecent.length + '周)');

console.log('口径A ASIN 数:', details.length);
console.log('口径A 总销售额:', totalSalesA.toFixed(2));
console.log('口径A 总利润:', totalProfitA.toFixed(2));
console.log('口径A 品类数:', categories.length);
console.log('口径A 人员:', personnel.map(p => p.name).join(', '));

// ============ 口径B：每日数据 ============
const sheetB = wb.Sheets[config.sheets.calibreB];
const bRows = xlsx.utils.sheet_to_json(sheetB, { header: 1, defval: '' });

// Excel 日期序列号 → "月.日" 字符串
function excelDateToStr(serial) {
  const date = new Date((serial - 25569) * 86400 * 1000);
  return (date.getMonth() + 1) + '.' + date.getDate();
}

// 从指定起始行提取 7 天数据
function extractDaily(startRow) {
  const data = [];
  for (let i = startRow; i < startRow + 7 && i < bRows.length; i++) {
    const row = bRows[i];
    if (row[0] === '' || row[0] === null) break;
    data.push({
      date: excelDateToStr(row[0]),
      sales: Number(row[1]) || 0,
      profit: Number(row[2]) || 0,
      completion: Number(row[3]) || 0
    });
  }
  return data;
}

const groupDaily = extractDaily(2);
const gaojieDaily = extractDaily(12);
const zhengchunyanDaily = extractDaily(22);
const zhangzhipengDaily = extractDaily(32);
const liyanDaily = extractDaily(42);

let totalSalesB = 0, totalProfitB = 0;
groupDaily.forEach(d => { totalSalesB += d.sales; totalProfitB += d.profit; });
console.log('\n口径B 本周总销售额:', totalSalesB.toFixed(2));
console.log('口径B 本周总利润:', totalProfitB.toFixed(2));
console.log('口径B 完成情况:', groupDaily.map(d => d.date + ':' + (d.completion * 100).toFixed(0) + '%').join(', '));

// ============ Sheet1：类目运营指标（四周对比） ============
// 结构：每隔 N 行出现一个"周区间标题"行（如 "9.21-9.27"），紧接着是表头 "产品线|总流量|广告曝光量|广告点击量|销量"
// 然后是 16 个类目的数据行，循环 4 次
let categoryMetrics = []; // [{ week, categories: [{name, traffic, exposure, clicks, sales}] }]
const sheetMetric = wb.Sheets[config.sheets.categoryMetrics];
if (sheetMetric) {
  const mRows = xlsx.utils.sheet_to_json(sheetMetric, { header: 1, defval: '' });
  let currentWeek = null;
  let currentCats = [];
  let hasHeader = false;

  for (let i = 0; i < mRows.length; i++) {
    const row = mRows[i];
    // 周区间标题行：第0列有值，其余为空
    if (row[0] && row[1] === '' && row[2] === '' && row[3] === '' && row[4] === '') {
      if (currentWeek && currentCats.length > 0) {
        categoryMetrics.push({ week: currentWeek, categories: currentCats });
      }
      currentWeek = row[0];
      currentCats = [];
      hasHeader = false;
      continue;
    }
    // 表头行：第0列是"产品线"
    if (row[0] === '产品线') { hasHeader = true; continue; }
    // 数据行：有产品线名称且不是空行
    if (hasHeader && row[0] && row[1] !== undefined && row[1] !== '') {
      currentCats.push({
        name: row[0],
        traffic: Number(row[1]) || 0,
        exposure: Number(row[2]) || 0,
        clicks: Number(row[3]) || 0,
        sales: Number(row[4]) || 0
      });
    }
  }
  // 最后一组
  if (currentWeek && currentCats.length > 0) {
    categoryMetrics.push({ week: currentWeek, categories: currentCats });
  }
}

// 提取所有类目名称（从第一周拿，所有周应该一致）
const categoryNames = categoryMetrics.length > 0
  ? categoryMetrics[0].categories.map(c => c.name)
  : [];

console.log('\n=== 类目运营指标（Sheet1）===');
console.log('周数:', categoryMetrics.length, '类目数:', categoryNames.length);
if (categoryMetrics.length > 0) {
  console.log('周区间:', categoryMetrics.map(m => m.week).join(', '));
}

// ============ 工作内容（Sheet「工作内容」） ============
// 结构：人名为分组行（单独一格），其后每行是一条工作内容，整行内容都在第 0 列
// 数据行格式：原文 -> 精简标题；分类标签1｜分类标签2
// 分类标签形如 logistics·物流 / ad·广告 / festival·节日营销 / report·汇报 / 空·默认
const sheetWork = wb.Sheets[config.sheets.workContent];
const roleNames = Object.keys(config.roles || {});
const workContent = [];
let teamWork = null; // 小组工作事项：分组名不在 roles 名单里的那组
if (sheetWork) {
  const wRows = xlsx.utils.sheet_to_json(sheetWork, { header: 1, defval: '' });
  let target = null;
  for (let i = 0; i < wRows.length; i++) {
    const cell = String(wRows[i][0] == null ? '' : wRows[i][0]).trim();
    if (!cell) continue;

    // 不含 "->" 即为分组行：姓名进成员列表，其余（如「小组工作事项」）进小组事项
    if (cell.indexOf('->') === -1) {
      if (roleNames.indexOf(cell) === -1) {
        teamWork = { name: cell, items: [] };
        target = teamWork;
      } else {
        target = { name: cell, items: [] };
        workContent.push(target);
      }
      continue;
    }
    if (!target) continue;

    // 原文 -> 精简标题；标签
    const parts = cell.split('->');
    const desc = parts[0].trim();
    const meta = parts.slice(1).join('->').trim();
    const semi = meta.split('；');
    const cat = semi[0].trim();
    // 标签：多个用 ｜ 分隔，取「·」前的英文 key（「空」代表默认）
    const tags = (semi[1] || '')
      .split(/[｜|]/)
      .map(s => s.trim())
      .filter(Boolean)
      .map(s => s.split('·')[0].trim())
      .filter(k => k && k !== '空');

    target.items.push({ cat, desc, tags });
  }
}

console.log('\n=== 工作内容 ===');
workContent.forEach(p => console.log(p.name + ':', p.items.length, '项'));
if (teamWork) console.log(teamWork.name + ':', teamWork.items.length, '项');

// ============ 月累计利润（各周利润求和，百分比自动计算） ============
// 两个数组均为「本月所有周含本周」，此处只做求和，不做任何二次累加
const mc = config.monthCumulative;
const monthCumProfitA = mc.profitAWeeks.reduce((s, v) => s + v, 0);
const monthCumProfitB = mc.profitBWeeks.reduce((s, v) => s + v, 0);
const monthCumProfitBCNY = monthCumProfitB * config.usdCnyRate;

const monthTarget = config.monthTarget;
const monthPctA = monthCumProfitA / monthTarget * 100;
const monthPctB = monthCumProfitBCNY / monthTarget * 100;

console.log('\n=== ' + config.monthLabel + '利润目标完成度 ===');
console.log('口径A ' + config.monthLabel + '累计利润:', monthCumProfitA.toFixed(2), '完成度:', monthPctA.toFixed(2) + '%');
console.log('口径B ' + config.monthLabel + '累计利润(USD):', monthCumProfitB.toFixed(2),
  '→ CNY:', monthCumProfitBCNY.toFixed(2), '完成度:', monthPctB.toFixed(2) + '%');

// ============ 环比 ============
const lw = config.lastWeek;
const salesWoWA = (totalSalesA - lw.salesA) / lw.salesA * 100;
const profitWoWA = (totalProfitA - lw.profitA) / lw.profitA * 100;
const salesWoWB = (totalSalesB - lw.salesB) / lw.salesB * 100;
const profitWoWB = (totalProfitB - lw.profitB) / lw.profitB * 100;

console.log('\n=== 环比 ===');
console.log('口径A 销售额:', salesWoWA.toFixed(2) + '%, 利润:', profitWoWA.toFixed(2) + '%');
console.log('口径B 销售额:', salesWoWB.toFixed(2) + '%, 利润:', profitWoWB.toFixed(2) + '%');

// ============ 输出 JSON ============
const output = {
  week: config.weekRange,
  lastWeek: config.lastWeekRange,
  monthLabel: config.monthLabel,
  weekLabels: mc.weekLabels,
  categoryMetrics,   // Sheet1 四周类目指标
  categoryNames,     // 所有类目名称列表
  workContent,       // 工作内容（按人分组，每条含 cat/desc/tags）
  teamWork,          // 小组工作事项（整行展示，可能为 null）
  calibreA: {
    details,
    categories,
    personnel,
    weeklyTrend: weeklyTrendRecent,   // 口径A sheet 内嵌的最近5周销售额/利润趋势
    totalSales: totalSalesA,
    totalProfit: totalProfitA,
    lastWeekSales: lw.salesA,
    lastWeekProfit: lw.profitA,
    monthCumProfit: monthCumProfitA,
    monthProfitTarget: monthTarget,
    monthProfitPct: monthPctA,
    salesWoW: salesWoWA,
    profitWoW: profitWoWA,
    // 本月各周利润（含本周），用于看板逐周拆分展示
    monthProfitWeeks: mc.profitAWeeks
  },
  calibreB: {
    groupDaily,
    gaojieDaily,
    zhengchunyanDaily,
    zhangzhipengDaily,
    liyanDaily,
    totalSales: totalSalesB,
    totalProfit: totalProfitB,
    monthCumProfit: monthCumProfitB,
    monthCumProfitCNY: monthCumProfitBCNY,
    // 本月各周利润（含本周），用于看板逐周拆分展示
    monthProfitWeeks: mc.profitBWeeks,
    lastWeekSales: lw.salesB,
    lastWeekProfit: lw.profitB,
    monthTarget: monthTarget,
    monthPct: monthPctB,
    usdCnyRate: config.usdCnyRate,
    salesWoW: salesWoWB,
    profitWoW: profitWoWB
  }
};

const jsonPath = path.join(__dirname, config.outputJson);
fs.writeFileSync(jsonPath, JSON.stringify(output, null, 2), 'utf8');
console.log('\n✅ JSON 已保存:', config.outputJson);
